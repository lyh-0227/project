//同时发送异步代码的次数
let ajaxTimes=0;
export const request=(params)=>{
    //判断URL中是否有/my/，有则需要带上请求头header、token，个人小程序id无法演示效果
    let header={...params.header};
    if(params.url.includes("/my/")){
        //带有/my/，需要拼接header，带上token
        header["Authorization"]=wx.getStorageSync("token");
    }

    ajaxTimes++;
    //显示加载中效果
    wx.showLoading({
        title: "加载中",
        mask: true
    });

    //定义公共的url
    const baseUrl="https://api-hmugo-web.itheima.net/api/public/v1"
    return new Promise(
        (resolve,reject)=>{
        
            //发送请求
            wx.request({
           
            //解构
            ...params,
            header:header,
            url:baseUrl+params.url,
          
            //成功函数
          success:(result)=>{
            resolve(result.data.message);
          },
           
           //失败函数
           fail: (err)=> {
            reject(err);
           },

           //关闭加载中效果
           complete: ()=> {
            
            ajaxTimes--;
            
            //对于多个请求是否关闭加载中进行判断
            if(ajaxTimes===0){
                wx.hideLoading();
            }
            
           }

        });
    
    })
}