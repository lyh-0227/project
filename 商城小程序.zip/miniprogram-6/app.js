// app.js
App({
  onLaunch: function (options) {

  },
  onShow: function (options) {

  },
  onHide: function () {

  },
  onError: function (msg) {

  },
  onPageNotFound:function(options){

  }
});