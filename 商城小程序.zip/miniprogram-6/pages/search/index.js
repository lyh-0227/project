// pages/search/index.js
/* 
1.输入框绑定值改变事件
  获取输入框的值->做合法性判断->验证通过后把输入框的值发送到后台->将返回的数据打印到页面上
2.防抖（防止抖动，输入结束后才发送请求）
  定义全局定时器id
  防抖一般用于输入框中，防止重复输入，重复发送请求
  
*/
import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods:[],
    //控制取消按钮是否显示
    isFocus:false,
    //输入框内的值
    inpValue:""
  },

  //定时器
  TimeId:-1,

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  
  //输入框改变事件
  handleInput(e){
    //1.获取输入框的值
    const {value}=e.detail;
    //2.检测输入合法性
    if(!value.trim()){
      //值不合法
      this.setData({
        goods:[],
        isFocus:false
      });
      return;
    }
    //3.输入值合法，准备发送请求获取数据
    this.setData({
      isFocus:true
    });
    //清除定时器
    clearTimeout(this.TimeId);
    //重新设置定时器，输入结束1s后发送请求
    this.TimeId=setTimeout(() => {
      this.qsearch(value);
    },1000);
  
  },

  //发送请求获取数据
  async qsearch(query){
    const res=await request({url:"/goods/qsearch",data:{query}});
    //console.log(res);
    this.setData({
      goods:res
    });
  },

  //点击取消事件，将搜索框清空、取消按钮隐藏、下方查询结果清空
  handleCancel(){
    this.setData({
      inpValue:"",
      isFocus:false,
      goods:[]
    });
  }

})