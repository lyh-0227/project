// pages/cart/index.js
/*
1.获取用户收货地址
   绑定点击事件
   获取用户对小程序所授予的关于获取地址的权限信息scope (authSetting scope.address)
   用户点击确定：scope=true 可以直接调用获取地址参数
   用户点击取消：scope=false 指导用户打开授权登录页面，用户重新给予权限时，调用获取地址的参数
   用户没有调用过：scope=undefined 可以直接调用获取地址参数
   将获取到的收货地址存入本地存储
2.加载完毕
  获取本地存储中的数据并赋值给data
3.onshow事件触发
  1.获取缓存中的购物车数组
  2.将购物车数据填充到data中
  3.第一次添加商品时checked属性为true
4.底部工具栏功能实现
  1.onShow获取缓存中的购物车数据
  2.根据购物车商品里的数据进行计算
5.总价格和总数量
  1.获取缓存中的购物车数组并遍历
  2.判断商品是否被选中
  3.被选中时则计算，总价格+=商品单价*商品数量；总数量+=商品数量
  4. 将总价格和总数量送回data
6.商品的选中、全选与反选
  1.选中：绑定change事件，获取到被修改的数据对象，商品对象的选中状态取反，重新填充到data和缓存中，重新进行第5步
  2.全选和反选：全选复选框绑定change事件，获取data中的选中状态，取反该选中状态；
  遍历购物车数组使其商品选中状态跟随全选变量的改变而改变；
  将购物车数组和全选状态重新设置回data中，购物车设置回缓存中。
7.商品数量的编辑功能
  1."+""-"绑定同一个点击事件，"+"->+1,"-"->-1
  2.传递被点击的商品id，goods_id
  3.获取data中的购物车数组，来获取需要被修改的商品对象
  4.若商品数量为1且用户点击"-"，则提示用户是否需要删除商品，否则直接修改商品数量属性num，将修改之后的数据设置回缓存和data中
8.结算功能
  1.判断是否存在收货地址和商品信息
  2.存在收货地址和商品信息，跳转到支付页面
*/

import { getSetting,chooseAddress,openSetting,showModal,showToast } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    allChecked:false,
    totalPrice:0,
    totalNum:0

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    //1.获取缓存中的收货地址信息
    const address=wx.getStorageSync("address");
    //2.获取缓存中的购物车数据
    const cart=wx.getStorageSync("cart")||[];
    //3.将地址存入
    this.setData({address});
    //4.全选、反选、总数量、总价格计算，调用封装好的setCart函数
    this.setCart(cart);
    
  },

  //点击获取地址
  async handleChooseAddress(){
    //1.获取权限状态
    try{
      const res1=await getSetting();
      const scopeAddress=res1.authSetting["scope.address"];
    //2.判断权限状态
      if(scopeAddress===false){
      //3.诱导用户打开授权页面
      await openSetting();
      }
     //4.重新调用api
      let address=await chooseAddress();
      address.all=address.provinceName+address.cityName+address.countyName+address.detailInfo;
      //5.存入缓存
      wx.setStorageSync("address", address);
    } 
    catch(error){
    console.log(error);
    }
  },

   //封装计算函数，方便调用和运算
  setCart(cart){
    //1.获取购物车数据
    wx.setStorageSync("cart", cart);
    
    //2.计算总数量、总价格并写入data中
    let totalPrice=0;
    let totalNum=0;
    let allChecked=true;
    cart.forEach(v=>{
      if(v.checked)
      {
        totalPrice+=v.num*v.goods_price;
        totalNum+=v.num;
      }
      else{
        allChecked=false;//判断是否全选
      }
    })
    //判断cart数组是否为空，如果长度不为0，则allChecked为定义值true，否则为false
    allChecked=cart.length!=0?allChecked:false;
    this.setData({
      cart,
      totalNum,
      totalPrice,
      allChecked
    });

  },

  //商品选中
  handleItemChange(e){
    
    //1.获取被修改的商品id
    const goods_id=e.currentTarget.dataset.id;
    
    //2.获取购物车数组
    let {cart}=this.data;
    
    //3.找到被修改的商品对象
    let index=cart.findIndex(v=>v.goods_id===goods_id);
    
    //4.选中状态取反
    cart[index].checked=!cart[index].checked;
    //5.调用封装方法进行计算和写入数据
    this. setCart(cart);
  },

  //商品全选功能
  handleItemAllCheck(){
    //1.获取data中的数据
    let {cart,allChecked}=this.data;
    //2.修改值
    allChecked=!allChecked;
    //3.循环修改cart中的商品选中状态
    cart.forEach(v=>v.checked=allChecked);
    //4.将修改后的数据填充回data或者缓存中
    this.setCart(cart);
  },

  //商品数量的编辑功能
  async handleItemNumEdit(e){
    //1.获取事件传递过来的参数
    const {operation,id}=e.currentTarget.dataset;
    //2.获取购物车数组
    let {cart}=this.data;
    //3.找到需要修改的商品的索引
    const index=cart.findIndex(v=>v.goods_id===id);
    //判断是否需要删除，如果商品数量为1且用户点击减号时弹出询问框
    if(cart[index].num===1&&operation===-1)
    {
      const res=await showModal({content:"您是否要把该商品从购物车中删除？"});
      if(res.confirm){
            
        cart.splice(index,1);
        this.setCart(cart);

      }
    }
    else{
    //4.进行数量修改
    cart[index].num+=operation;
    //5.设置回缓存和data中
    this.setCart(cart);
    }
    
  },
  

  //结算功能
  async handlePay(){
    const {address,totalNum}=this.data;
  
    //1.判断收货地址是否存在
    if(!address.userName)
    {   
      await showToast({title:"请您先选择收货地址！"});
      return; 
    }
  
    //2.判断购物车中是否有商品
    if(totalNum===0)
    {
      await showToast({title:"您还未选购任何商品！"});
      return; 
    }

    //3.通过前两步验证后可跳转到支付页面
    wx.navigateTo({
      url: '/pages/pay/index'
    });
  
  }

})