// pages/pay/index.js
/* 
1.页面加载时
  1.从缓存中获取购物车数据，渲染到页面中（只有当checked=true时才会结算）
2.微信支付
  1.企业账号
  2.小程序后台中加入白名单
3.支付按钮
  1.先判断缓存中是否有token；没有：跳转到授权页面获取token，有：正常执行下一步，创建订单，获取订单编号
  2.由于是个人小程序账号，无法使用支付功能，所以无法获取token，以下内容为尝试性代码，无法进行调试操作
  3.完成微信支付后，将已支付的商品进行删除，将操作后的购物车数据填充回缓存中并跳转页面（无法调试）
*/

import { getSetting,chooseAddress,openSetting,showModal,showToast,requestPayment } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
import {request}from '../../request/index.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    totalPrice:0,
    totalNum:0

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    //1.获取缓存中的收货地址信息
    const address=wx.getStorageSync("address");
    //2.获取缓存中的购物车数据
    let cart=wx.getStorageSync("cart")||[];
    //3.将地址存入
    this.setData({address});
    //4.选出checked=true的商品，用filter过滤
    cart=cart.filter(v=>v.checked);
    //5.计算总数量、总价格并写入data中
    let totalPrice=0;
    let totalNum=0;
    cart.forEach(v=>{
        
      totalPrice+=v.num*v.goods_price;
      totalNum+=v.num;
        
    })
    this.setData({
      cart,
      totalNum,
      totalPrice,
      address
    });
    
  },

  //点击支付事件
  async handleOrderPay(){
    try{
      //1.判断缓存中是否存在token
      const token=wx.getStorageSync("token");
      //2.判断token是否存在，由于是个人小程序账号，无法使用支付功能，所以无法获取token，以下内容为尝试性代码
      if(!token){
        wx.navigateTo({
          url: '/pages/auth/index',
        });
        return;
      }
      //3.创建订单
      //准备请求头参数
      //const header={Authorization:token};
      //准备请求体参数，总价格、地址、商品数组
      const order_price=this.data.totalPrice;
      const consignee_addr=this.data.address.all;
      const cart=this.data.cart;
      let goods=[];
      cart.forEach(v=>goods.push({
        goods_id:v.goods_id,
        goods_number:v.goods_number,
        goods_price:v.goods_price
      }))
      const orderParams={order_price, consignee_addr, goods};
      //4.准备发送请求
      const {order_number}=await request({url:"/my/orders/create",method:"POST",data:orderParams});
      //5.发起预支付的接口
      const {pay}=await request({url:"/my/orders/req_unifiedorder",method:"POST",data:{order_number}});
      //6.发起微信支付
      await requestPayment(pay);
      //7.查询后台订单状态
      const res=await request({url:"/my/orders/chkOrder",method:"POST",data:{order_number}});
      await showToast({title:"支付成功"});
      //手动删除已经支付的商品数据，并将购物车数据填充回缓存
      let newCart=wx.getStorageSync("cart");
      newCart=newCart.filter(v=>!v.checked);
      wx.setStorageSync("cart", newCart);
      //8.支付成功后返回订单页面
      wx.navigateTo({
        url: '/pages/ordere/index'
      });
      
    }
    catch(error){
      await showToast({title:"支付失败"});
    }
  
  }

})