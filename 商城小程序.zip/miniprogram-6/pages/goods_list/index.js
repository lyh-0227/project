// pages/goods_list/index.js
/*
用户上划页面，加载下一页数据
1.找到滚动条触底事件
2.判断是否有下一页数据
 （1）获取当前总页数  由总条数计算可得，总页数 = Math.ceil(总条数/页容量)
 （2）获取当前的页码  pagenum
 （3）判断当前页码是否大于或等于总页数
      是则没有下一页数据
3.没有下一页数据弹出提示框，有下一页数据则加载下一页数据
  有下一页数据：当前页码++，重新发送请求，获得数据后进行拼接
  没有下一页数据：
*/

/* 
下拉刷新页面
  1.触发刷新事件，需要在json文件中开启一个配置项,找到触发下拉刷新的事件
  2.重置数组数据
  3.重置页码为1
  4.重新发送请求
  5.数据请求后需要手动关闭等待效果
*/

import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs:[
        {
          id:0,
          value:"综合",
          isActive:true
        },
        {
          id:1,
          value:"销量",
          isActive:false
        },
        {
          id:2,
          value:"价格",
          isActive:false
        }
      
      ],
      
    goodsList:[]
 
  },

  /*接口参数*/
  QueryParams:{
    query:"",
    cid:"",
    pagenum:1,
    pagesize:10
  },

  //总页数
  totalPages:1,


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    //将获取到的参数赋值给接口
    this.QueryParams.cid=options.cid||"";
    this.QueryParams.query=options.query||"";
    this.getGoodsList();
  
  },

  //标题点击事件，从子组件传递
  handleTabsItemChange(e){
    
    //1.获取被点击的标题索引
    const {index}=e.detail;
    
    //2.修改原数组，定义tabs保存数据，用forEach遍历，如果某一标题被点击，则isActive属性被激活，否则不激活
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    
    //3.赋值到data中
    this.setData({
      tabs
    })
  
  },

  //获取商品列表数据，使用es7的async和await发送请求并获得数据
  async getGoodsList(){

    const res=await request({url:"/goods/search",data:this.QueryParams});
    //获取总条数
    const total=res.total;
    
    //计算总页数
    this.totalPages=Math.ceil(total/this.QueryParams.pagesize);
    
    //拼接旧的数据和新获取的数据
    this.setData({
      goodsList:[...this.data.goodsList,...res.goods]
    })
    
    //关闭下拉刷新的窗口
    wx.stopPullDownRefresh();

  },

  //页面上划，滚动条触底时触发
  onReachBottom(){
    
    //判断是否存在下一页数据
    if(this.QueryParams.pagenum>=this.totalPages){
    
    //没有下一页数据
    wx.showToast({
      
      title: '没有下一页数据',
      image:'../../icons/warning.png'
       
    });
    }
    
    else{
      
      //存在下一页数据
      this.QueryParams.pagenum++;
      this.getGoodsList();
    
    }
  
  },

  //下拉刷新事件
  onPullDownRefresh(){
    
    //1.重置数组
    this.setData({
      goodsList:[]
    })
    
    //2.重置页码为1
    this.QueryParams.pagenum=1;
  
    //3.重新发送请求
    this.getGoodsList();
  
  }
  
})