// pages/goods_detail/index.js
/*
1.发送请求获取数据
2.点击轮播图预览大图
  (1)给轮播图绑定点击事件
  (2)调用小程序api previewImage
3.点击加入购物车
  (1)先绑定点击事件
  (2)获取缓存中的购物车的数组数据
  (3)判断当前商品是否存在与购物车内
  存在：修改数据，购物车中数量++，将数组填充回缓存中；
  不存在：给购物车数组中添加新元素，新元素带有购买数量属性，将数组填充回缓存中
  (4)弹出相应提示
4.商品收藏
  (1)页面调用onShow事件时，加载商品收藏数据
  (2)判断当当前商品是否被收藏，是：改变收藏图标；否：什么都不做
  (3)点击商品收藏按钮：判断该商品是否存在于缓存数组中；已存在：删除商品，不存在：将商品添加到收藏数组中以及缓存中
*/
import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //页面数据变量
    goodsObj:{},
    //商品是否被收藏
    isCollect:false

  },

  //商品对象
  GoodInfo:{},

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function () {
    //拿到options对象
    let pages =  getCurrentPages();
    let currentPage=pages[pages.length-1];
    let options=currentPage.options;
   
    const {goods_id}=options;
    this.getGoodsDetail(goods_id);


  },
  
  //获取商品详情数据
  async getGoodsDetail(goods_id){
    //给页面数据赋值
    const goodsObj=await request({url:"/goods/detail", data:{goods_id}});
    //给轮播图放大图片数组赋值
    this.GoodInfo=goodsObj;
    //1.获取缓存中的商品收藏数组
    let collect=wx.getStorageSync("collect")||[];
    //2.判断商品是否被收藏
    let isCollect=collect.some(v=>v.goods_id===this.GoodInfo.goods_id);
    this.setData({
      goodsObj:{
        goods_name:goodsObj.goods_name,
        goods_price:goodsObj.goods_price,
        
        //iphone手机不识别webp格式图片,确保存在webp格式图片，将webp格式文件修改为JPG图片文件
        //搜索webp文件，g表示全局，''中为转换后的格式
        goods_introduce:goodsObj.goods_introduce.replace(/\.webp/g,'.jpg'),
        pics:goodsObj.pics,
         
      },
      isCollect
    })
  },

  //点击轮播图放大预览大图
  handlePreviewImage(e){
    // 1.构造图片数组urls，map构造新的变量返回pics_mid
    const urls=this.GoodInfo.pics.map(v=>v.pics_mid);
    //2.接收传递过来的url
    const current=e.currentTarget.dataset.url;
    wx.previewImage({
      current: current,
      urls: urls
    });
  },

  //点击加入购物车
  handleCartAdd(){
    //1.获取缓存中的购物车数据，"||[]"表示转换为数组形式
    let cart=wx.getStorageSync("cart")||[];
    //2.判断数组对象是否存在于购物车数组中，有则为当前索引页，否则为-1
    let index=cart.findIndex(v=>v.goods_id===this.GoodInfo.goods_id);
    if(index===-1){
    
    //3.判断是否为第一次添加 
    //第一次添加商品，数量为1，将数组填回缓存
      this.GoodInfo.num=1;
      this.GoodInfo.checked=true;
      cart.push(this.GoodInfo);

    }
    else{
    //不是第一次添加商品，执行数量++
      cart[index].num++;
    }
    
    //将购物车添加到缓存中
    wx.setStorageSync("cart",cart);
    
    //4.弹窗提示
    wx.showToast({
      title: '加入成功',
      icon: 'success',
      mask: true
    });

  },

  //收藏按钮点击事件
  handleCollect(){
    
    let isCollect=false;
    //1.获取缓存中的商品收藏数组
    let collect=wx.getStorageSync("collect")||[];
    //2.判断该商品是否被收藏过
    let index=collect.findIndex(v=>v.goods_id===this.GoodInfo.goods_id);
    //3.当index！=-1时，已经收藏过该商品，点击将取消收藏，并弹出提示
    if(index!==-1){
      collect.splice(index,1);
      isCollect=false;
      wx.showToast({
        title: '取消成功',
        icon: 'success',
        duration: 1500,
        mask: true,
      });
    }
    //没有收藏过，点击将添加该商品，并弹出提示
    else{
      collect.push(this.GoodInfo);
      isCollect=true;
      wx.showToast({
        title: '收藏成功',
        icon: 'success',
        duration: 1500,
        mask: true,
      });
    }
    //4.把数组存入到缓存中
    wx.setStorageSync("collect", collect);
    //5.修改data中的属性isCollect
    this.setData({
      isCollect
    })
  
  }
  
})