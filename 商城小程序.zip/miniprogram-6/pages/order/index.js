// pages/order/index.js
/*  

(由于为个人小程序，所以无法使用支付功能，因此也不会产生订单信息，所以以下代码为尝试性代码，无法进行调试，已将无法调试并报错的内容进行说明和注释)

1.页面被打开的时候
  判断缓存中是否有token，没有：跳转到授权页面；有：进行下一步
  获取URL中的参数type，onShow事件与onLoad事件不同，无法在形参上接收options
  根据type决定页面标题数组哪一项被选中，发送请求获取订单数据，渲染页面 
2.点击不同标题，重新发送请求获取数据，进行渲染页面

*/

import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //orders:[],
    tabs:[
      {
        id:0,
        value:"全部",
        isActive:true
      },
      {
        id:1,
        value:"待付款",
        isActive:false
      },
      {
        id:2,
        value:"待发货",
        isActive:false
      },
      {
        id:3,
        value:"退货/退款",
        isActive:false
      }
    
    ]
  },
  
  
  //根据type值确定标题数组被选中的项目
  changeTitleByIndex(index){

    //修改原数组，定义tabs保存数据，用forEach遍历，如果某一标题被点击，则isActive属性被激活，否则不激活
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    
    //赋值到data中
    this.setData({
      tabs
    })
  
  },
  
  
  //标题点击事件，从子组件传递
  handleTabsItemChange(e){
    
    //获取被点击的标题索引
    const {index}=e.detail;
    this.changeTitleByIndex(index);
    //重新发送请求
    //this.getOrders(index+1);
  
  },

  onShow (options) {
    // //1.判断缓存中是否有token
    // const token=wx.getStorageSync("token");
    // //如果token不存在，跳转到授权页面，否则继续执行
    // if(!token){
    //   wx.navigateTo({
    //     url: '/pages/auth/index',
    //   });
    //   return;
    // }
    //2.获取小程序页面栈(可理解为数组)，长度最大10个页面
    let pages=getCurrentPages();
    //3.数组中索引最大的页面是当前页面，存在options参数，可以获取options参数
    let currentPage=pages[pages.length-1];
    //4.获取URL上的type参数
    const {type}=currentPage.options;
    //5.激活选中页面标题，index=type-1
    this.changeTitleByIndex(type-1);
    this.getOrders(type);
  },

  //获取订单列表
  //(由于为个人小程序，所以无法使用支付功能，因此也不会产生订单信息，所以以下代码为尝试性代码，无法进行调试)
  async getOrders(type){
    const res=await request({url:"/my/orders/all",data:{type}});
    // this.setData({
    //orders:res.orders.map(v=>({...v,create_time_cn:(new Date(v.create_time*1000).toLocaleString())}));
    // });
  }
})