//引入用来发送请求的方法（promise优化代码）
import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';

// pages/category/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      
    //左侧的菜单数据
      leftMenuList:[],
    //右侧的商品数据
      rightContent:[],
    //被点击后的左侧菜单
     currentIndex:0,
    //右侧滚动条距离顶部的距离
     scrollTop:0

  },

  
  //接口的返回数据
  Cates:[],

  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    /* 
    1.判断本地存储中是否含有旧的数据
       本地存储的数据样式：{time:Date.now(),data:[]}
    2.没有旧的数据，直接发送新的请求
    3.有旧的数据但没有过期，使用本地存储的旧的数据
    */

    //获取本地存储中的数据
    const Cates=wx.getStorageSync("cates");

    //判断
    if(!Cates)
    {
        //不存在则发送请求获取数据
        this.getCates();
    }
    else{
        //有旧的数据，定义过期时间为10秒钟，判断是否过期，过期则重新发送请求
        if(Date.now()-Cates.time>1000*10){
          this.getCates();
        }
        else{
          //没有过期，可以使用旧的数据，重新加载页面
          this.Cates=Cates.data;
          let leftMenuList=this.Cates.map(v=>v.cat_name);
          let rightContent=this.Cates[0].children;

          this.setData({
      
                leftMenuList,
                rightContent

          })
        }

    }


  },

  
  //获取分类数据
  async getCates(){
      
    //初始的获取数据方式
    // request({

    //       url:"/categories"

    // })

    // .then(res=>{
          
    //       //给返回接口数组赋值
    //       this.Cates=res.data.message;

    //       //把接口的数据存入本地存储中
    //       wx.setStorageSync("cates", {time:Date.now(),data:this.Cates});

    //       //构造左侧的彩单数据，变量名来自于返回的json文件对象
    //       let leftMenuList=this.Cates.map(v=>v.cat_name);
          
    //       //构造右侧的商品数据
    //       let rightContent=this.Cates[0].children;

    //       this.setData({
      
    //             leftMenuList,
    //             rightContent

    //       })
   

    // })
    
    
    
    //es7获取数据方式
    //1.使用es7的async和await来发送异步请求
    const res=await request({url:"/categories"});
      //给返回接口数组赋值
    this.Cates=res;

      //把接口的数据存入本地存储中
    wx.setStorageSync("cates", {time:Date.now(),data:this.Cates});

      //构造左侧的彩单数据，变量名来自于返回的json文件对象
    let leftMenuList=this.Cates.map(v=>v.cat_name);
          
     //构造右侧的商品数据
    let rightContent=this.Cates[0].children;

    this.setData({
      
      leftMenuList,
      rightContent

    })

},

  
  //左侧菜单点击事件
  handleItemTap(e){

      /*
      1.获取被点击标题的索引
      2.给data中的currentIndex赋值
      3.根据不同的索引来渲染右侧内容
      */
      const {index}=e.currentTarget.dataset;
      let rightContent=this.Cates[index].children;
      this.setData({
         
          currentIndex:index,
          rightContent,
          scrollTop:0//重新设置右侧滚动条距离顶部的距离

      })
      
  }
  
})