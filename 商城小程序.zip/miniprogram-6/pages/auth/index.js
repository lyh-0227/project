// pages/auth/index.js
import{ request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
import {login} from "../../utils/asyncWx.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  async handleGetUserInfo(e){
    try{
    //1.获取用户信息
    const {encryptedData,rawData,iv,signature}=e.detail;
    //2.获取小程序登录成功后的code
    const {code}=await login();
    const loginParams={encryptedData,rawData,iv,signature,code};
    //3.发送请求，获取用户token值，由于是个人小程序账号，无法使用支付功能，所以无法获取token，以下内容为尝试性代码
    const {token}=await request({url:"/users/wxlogin",data:loginParams,method:"post"});
    //4.把token存储到缓存中，跳转回上一个页面
    wx.setStorageSync("token", token);
    wx.navigateBack({
      delta: 1
    });
    }
    catch(error){
    console.log(error);
    }
  }
})