// index.js
const util = require('../../utils/util.js');

Page({
  data: {
    
    //控制首页和时钟页的显示隐藏
    clockShow:false,
    
    //滑块显示时间
    time:"1",

    //定时器
    mTime:60000,
    
    //单位换算、计算使用
    rate:"",
    
    //任务数组
    cateArr:[
      {
        icon:"work",
        text:"工作"
      },
      {
        icon:"study",
        text:"学习"
      },
      {
        icon:"think",
        text:"思考"
      },
      {
        icon:"write",
        text:"写作"
      },
      {
        icon:"sport",
        text:"运动"
      },
      {
        icon:"read",
        text:"阅读"
      }
    ],
    
    //任务点击后高亮
    cateActive:"0",

    //时钟页的倒计时变量
    timeStr:"01:00",

    //时钟页面的按钮显示隐藏变量
    okShow:false,
    pauseShow:true,
    ContinueCancelShow:false,

    //计时器时间变量
    timer:null
  },

  onLoad() {
  //屏幕宽度750prx，获取系统信息wx.getSystemInfoSync();
  //750rpx/res.windowwidth=?/res.windowheight
  let res=wx.getSystemInfoSync();
  let rate=750/res.windowWidth;
  //console.log(rate);
  this.setData({
    rate
  });
  },
  
  //滑块移动事件
  sliderChange(e){
    this.setData({
      time:e.detail.value
    });    
  },
  
  //目标选择事件
  clickCate(e){
    //console.log(e);
    this.setData({
      cateActive:e.currentTarget.dataset.index
    });
  },

  //“开始专注”按钮点击事件
  start(){
    this.setData({  
      clockShow:true,
      mTime:this.data.time*60*1000,
      //倒计时，判断现有时间是否大于等于10，若大于等于10，则补上“：00”，否则在前方补“0”
      timeStr:parseInt(this.data.time)>=10?this.data.time+":00":"0"+this.data.time+":00"
    });
    this.drawBg();
    this.drawActive();
  },
  
  //画圆
  drawBg(){
    //转化为px单位
    let lineWidth=6/this.data.rate;
    let ctx=wx.createCanvasContext("progress_bg");
    //设置宽和样式
    ctx.setLineWidth(lineWidth);
    ctx.setStrokeStyle("#ffffff");
    ctx.setLineCap("round");
    //设置路径
    ctx.beginPath();
    //调用arc画圆(x坐标,y坐标，半径,开始角度,结束角度,参数)
    ctx.arc(400/this.data.rate/2 , 400/this.data.rate/2, 400/this.data.rate/2-2*lineWidth, 0 ,2*Math.PI );
    ctx.stroke();
    ctx.draw();
  },
  
  //动态画圆和倒计时
  drawActive(){
    let _this=this;
    //设置定时器
    let timer= setInterval(()=>{
      
      //起点：1.5，终点：3.5，角度：2π，定义mTime=60000,100ms执行一次，则需要执行600次，每次执行的角度为2/600
      let angle=1.5+2*(_this.data.time*60*1000-_this.data.mTime)/(_this.data.time*60*1000);
      
      //计时器每运行一次，减去一次运行时间
      let currentTime=_this.data.mTime-100
   
      _this.setData({
        mTime:currentTime
      })
      
      //判断动态画圆
      if(angle<3.5){
        
        //倒计时
        if(currentTime%1000==0){
          //将时间化成秒
          let timeStr1=currentTime/1000;
          //获取分钟数
          let timeStr2=parseInt(timeStr1/60);
          //获得不足1分钟剩余的秒数，若秒数大于等于10，则直接显示剩余的秒数，否则前面补“0”
          let timeStr3=(timeStr1-timeStr2*60)>=10?(timeStr1-timeStr2*60):"0"+(timeStr1-timeStr2*60);
          //对分钟数进行处理，若分钟数介于0-10之间，则在分钟数前补“0”，否则直接显示
          let timeStr4=timeStr2>=10?timeStr2:"0"+timeStr2;
          //动态改变数值
          _this.setData({
            timeStr:timeStr4+":"+timeStr3
          });

        }
        
        //动态画圆
        //转化为px单位
        let lineWidth = 6/_this.data.rate;
        let ctx = wx.createCanvasContext("progress_active");
        //设置宽和样式
        ctx.setLineWidth(lineWidth);
        ctx.setStrokeStyle("#E7624F");
        ctx.setLineCap("round");
        //设置路径
        ctx.beginPath();
        //调用arc画圆(x坐标,y坐标，半径,开始角度,结束角度,参数)
        ctx.arc(400/_this.data.rate/2 , 400/_this.data.rate/2, 400/_this.data.rate/2-2*lineWidth ,1.5*Math.PI , angle *Math.PI );
        ctx.stroke();
        ctx.draw();

      }
      else{
        //将记录存入缓存
        let logs=wx.getStorageSync("logs")||[];
        logs.unshift({
          data:util.formatTime(new Date),
          cate:_this.data.cateActive,
          time:_this.data.time
        });
        wx.setStorageSync("logs", logs);
        
        //清空定时器
        clearInterval(timer);
        //在倒计时结束后，时间变为00:00
        _this.setData({
          timeStr:"00:00",
          okShow:true,
          pauseShow:false,
          ContinueCancelShow:false
        });
      }
      
    }, 100);
    _this.setData({
      timer
    });
  },

  //时间暂停按钮
  pause(){
    clearInterval(this.data.timer);
    this.setData({
      pauseShow:false,
      ContinueCancelShow:true,
      okShow:false
    });
    wx.showToast({
      title: '休息一下吧！',
      icon: 'none',
      duration: 1500,
      mask: true
    });
  },

  //继续按钮
  continue(){
    this.drawActive();
    this.setData({
      pauseShow:true,
      ContinueCancelShow:false,
      okShow:false
    });
    wx.showToast({
      title: '请您继续专注！',
      icon: 'success',
      duration: 1500,
      mask: true
    });
  },

  //取消按钮
  cancel(){
    clearInterval(this.data.timer);
    wx.showToast({
      title: '放弃有些可惜哦！',
      icon: 'none',
      duration: 1500,
      mask: true,
      success:()=>{
        setTimeout(()=>{
          this.setData({
            pauseShow:true,
            ContinueCancelShow:false,
            okShow:false,
            clockShow:false
          });
        },1000)
      }

    });
   
    
  },

  ok(){
    clearInterval(this.data.timer);
    wx.showToast({
      title: '恭喜您完成任务！',
      icon: 'success',
      duration: 1500,
      mask: true,
      success:()=>{
        setTimeout(()=>{
          this.setData({
            pauseShow:true,
            ContinueCancelShow:false,
            okShow:false,
            clockShow:false
          });
        },1000)
      }
    });
  }

})
