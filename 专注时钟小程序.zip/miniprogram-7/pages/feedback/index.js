// pages/feedback/index.js
/*
1.点击“+”
  调用小程序内置的选择图片的api->获取图片路径（数组）->将图片路径存入到data中->将图片数组进行循环显示（自定义组件）
2.点击“x”删除图片
  获取被点击元素的索引->获取data中的图片数组->根据索引删除数组中对应的元素->把数组设置回data中
3.点击提交
  获取文本域的内容->对文本域内容进行合法性验证->不通过弹窗提示，通过弹窗提示提交成功->清空当前页面  
*/

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs: [
      {
        id: 0,
        value: "体验问题",
        isActive: true
      },
      {
        id: 1,
        value: "提出建议",
        isActive: false
      }
    ],
    suggest:[
      {
        text:"体验遇到问题"
      },
      {
        text:"功能建议"
      },
      {
        text:"其他问题"
      }
      
    ],
    //储存被选中图片
    //chooseImgs:[],
    //文本域内容
    textVal:"",
    cateActive:"0"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  handleTabsItemChange(e){
    
    //1.获取被点击的标题索引
    const {index}=e.detail;
    
    //2.修改原数组，定义tabs保存数据，用forEach遍历，如果某一标题被点击，则isActive属性被激活，否则不激活
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    
    //3.赋值到data中
    this.setData({
      tabs
    })
  
  },

  //点击选择问题
  clickCate(e){
    //console.log(e);
    this.setData({
      cateActive:e.currentTarget.dataset.index
    });
  },
  
  // //点击加号选择图片事件
  // handleChooseImg(){
  // //1.调用小程序内置选择图片的api并赋值
  // wx.chooseImage({
  //   //最大数量
  //   count: 9,
  //   //图片类型（原始、压缩）
  //   sizeType: ['original','compressed'],
  //   //来源（相册、照相机）
  //   sourceType: ['album','camera'],
  //   success: (result)=>{
  //     //将已选择的图片和未选择的图片进行拼接
  //     //console.log(result);
  //     this.setData({
  //       chooseImgs:[...this.data.chooseImgs,...result.tempFilePaths]
  //     });
  //   }
  // });
  // },

  // //删除图片
  // handleRemoveImg(e){
  //   //2.获取被点击图片的索引
  //   const {index}=e.currentTarget.dataset;
  //   //3.获取data中的图片数组
  //   let{chooseImgs}=this.data;
  //   //4.删除所选中的图片
  //   chooseImgs.splice(index,1);
  //   //5.将图片数组重新设置回data中
  //   this.setData({
  //     chooseImgs
  //   });
  // },

  //文本域输入事件
  handleTextInput(e){
    this.setData({
      textVal:e.detail.value
    });
  },

  //"提交"按钮点击事件
  handleFormSubmit(){
    //1.获取文本域的内容
    const {textVal}=this.data;
    //2.合法性验证，是否为空
    if(!textVal.trim()){
    //不合法
    wx.showToast({
      title: '您的输入不合法',
      icon: 'none',
      mask: true
    });
    return;
    }
    //3.不为空时则弹窗提示提交成功并返回上一页
    else if(textVal.trim()!=""){
      //提示提交成功
      wx.showToast({
        title: '提交成功',
        icon: 'success',
        mask: true,
        success:()=>{
        
        //4.重置页面
        this.setData({
        textVal:"",
        chooseImgs:[]
        });
        
        //5.延迟执行关闭
        setTimeout(() => {
          wx.navigateBack({
            delta: 1
          });
        },1500);
        }
      
      });
    
    }

  }

})