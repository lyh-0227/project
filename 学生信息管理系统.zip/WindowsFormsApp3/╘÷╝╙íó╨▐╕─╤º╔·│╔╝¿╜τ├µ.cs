﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 增加_修改学生成绩界面 : Form
    {
        string[] str = new string[7];//接收传递来的选中的信息
        public 增加_修改学生成绩界面()//插入使用
        {
            InitializeComponent();
            button3.Visible = false;//插入成绩时隐藏修改保存按钮

        }
        public 增加_修改学生成绩界面(string[] a)//修改使用
        {
            InitializeComponent();
            for (int i = 0; i < 7; i++)
            {
                str[i] = a[i];
            }
            textBox1.Text = str[0];
            textBox2.Text = str[1];
            textBox3.Text = str[2];
            textBox4.Text = str[3];
            textBox5.Text = str[4];
            textBox6.Text = str[5];
            textBox7.Text = str[6];//定义一个数组，存储用户修改之后的数据，并依次显示在textbox1--textbox5中
            button1.Visible = false;//修改时隐藏插入插入按钮
        }

        private void 增加_修改学生成绩界面_Load(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals("") || textBox2.Text.Equals("") || textBox3.Text.Equals("") || textBox4.Text.Equals("") || textBox5.Text.Equals("")||textBox6.Text.Equals("")||textBox7.Text.Equals(""))
            {
                MessageBox.Show("您的输入操作不完整，请检查后再输入！", "友情提示");

            }//进行修改时如果所有信息为空，则提示输入不完整
            else
            {
                if (textBox1.Text != str[0])//如果第一个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Id='" + textBox1.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（学号修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[0] = textBox1.Text;//将修改后的textbox里的内容当做数组中的第一个数据

                }
                if (textBox2.Text != str[1])//如果第二个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Name='" + textBox2.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（姓名修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[1] = textBox2.Text;//将修改后的textbox里的内容当做数组中的第二个数据
                }
                if (textBox3.Text != str[2])//如果第三个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Class='" + textBox3.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（专业班级修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[2] = textBox3.Text;//将修改后的textbox里的内容当做数组中的第三个数据
                }
                if (textBox4.Text != str[3])//如果第四个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Course1='" + textBox4.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句(第一门课程名称修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[3] = textBox4.Text;//将修改后的textbox里的内容当做数组中的第四个数据
                }
                if (textBox5.Text != str[4])//如果第五个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Score1='" + textBox5.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（第一门课程成绩修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[4] = textBox5.Text;//将修改后的textbox里的内容当做数组中的第五个数据
                }
                if (textBox6.Text != str[5])//如果第六个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Course2='" + textBox6.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（第二门课程名称修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[5] = textBox6.Text;//将修改后的textbox里的内容当做数组中的第六个数据
                }
                if (textBox7.Text != str[6])//如果第七个textbox中的信息在修改后与修改前不一样
                {
                    string sql = "update Score set Score2='" + textBox7.Text + "'where Id='" + str[0] + "'and Name='" + str[1] + "'";//定义变量sql储存数据库语句（第二门课程成绩修改）
                    Tool tool = new Tool();
                    tool.Excute(sql);//定义Tool类变量tool并执行sql语句
                    str[6] = textBox7.Text;//将修改后的textbox里的内容当做数组中的第七个数据
                }
                MessageBox.Show("修改成功！", "友情提示");//当所有修改完成后提示修改成功
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == ""||textBox6.Text==""||textBox7.Text=="")
            {
                MessageBox.Show("您的输入不完整，请检查后再次输入！", "友情提示");//增加的学生信息里有一条为空，则提示信息不完整
            }
            else
            {
                string sql = "Insert into Score values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "')";
                //否则定义string类变量sql，用来执行插入的数据库sql语句（插入的信息即为七个textbox中的文本内容）
                Tool tool = new Tool();
                int i = tool.Excute(sql);//定义了一个Tool类的变量tool，并执行sql语句，定义变量i，用来储存返回的受影响行数
                if (i > 0)//如果受影响行数大于0
                {
                    MessageBox.Show("增加成功！", "友情提示");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    this.Close();
                    //提示增加成功，并将已完成增加操作的textbox清空，页面关闭
                }


            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }
    }
}
