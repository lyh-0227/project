﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System. Data;

namespace WindowsFormsApp3
{
    class Tool//关于数据库操作的类
    {
       
        public SqlConnection connection()
        {  
            string str = "Data Source=DESKTOP-COHIN99;Initial Catalog=student;Integrated Security=True";//定义连接字符串
            SqlConnection sc = new SqlConnection(str);//到数据库里打开数据库连接（连接字符串对应的数据库）
            sc.Open();//打开数据库连接
            return sc;
        }
        public SqlCommand command(string sql)
        {
            SqlCommand sc = new SqlCommand(sql, connection());//数据库的操作,调用连接数据库的方法
            return sc;
        }
        //用于delete updata insert，返回受影响的行数
        public int Excute(string sql)
        {
            return command(sql).ExecuteNonQuery();//对于连接的数据库操作返回受影响行数
        }
        //用于select，返回SqldataReader对象，包含select数据
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader();//将SqlCommand.CommandText发送到SqlCommand.Connection，并生成SqlDataReader
        }
    }
}
