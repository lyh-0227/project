﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 学生成绩管理 : Form
    {
        public 学生成绩管理()
        {
            InitializeComponent();
        }

    

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Table()
        {
            dataGridView1.Rows.Clear();
            string sql = "select * from Score";//查询student表中所有数据，并用string类型变量sql储存
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);//定义Tool类型的变量tool，并执行sql语句
            while (dr.Read())//如果执行
            {
                string a, b, c, d, e, f, g;
                a = dr["Id"].ToString();
                b = dr["Name"].ToString();
                c = dr["Class"].ToString();
                d = dr["Course1"].ToString();
                e = dr["Score1"].ToString();
                f = dr["Course2"].ToString();
                g = dr["Score2"].ToString();
                string[] str = { a, b, c, d, e , f, g };
                dataGridView1.Rows.Add(str);//定义七个string类型变量a，b，c，d，e，f，g，分别用来储存选择的学生的学号、姓名、班级、两门课的名称和成绩，并按行加入表格

            }
            dr.Close();//关闭连接
        }

        private void 学生成绩管理_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
            Table();
        }

        private void 修改学生成绩ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] str = { dataGridView1.SelectedCells[0].Value.ToString(), dataGridView1.SelectedCells[1].Value.ToString(), dataGridView1.SelectedCells[2].Value.ToString(), dataGridView1.SelectedCells[3].Value.ToString(), dataGridView1.SelectedCells[4].Value.ToString(), dataGridView1.SelectedCells[5].Value.ToString(), dataGridView1.SelectedCells[6].Value.ToString() };
            //定义string类型的数组，用来储存表中选中的行的每一列信息
            增加_修改学生成绩界面 增加_修改学生成绩界面 = new 增加_修改学生成绩界面(str);
            增加_修改学生成绩界面.ShowDialog();//将所有的选中信息传递到教师端学生信息管理界面，并运行教师端学生信息管理界面
        }

        private void 刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Table();
        }

        private void 删除学生成绩ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("确定要删除所选项吗？", "友情提示", MessageBoxButtons.OKCancel);//定义一个变量r，用来储存消息询问框的结果
            if (r == DialogResult.OK)//如果选择的OK
            {
                string id, name;
                id = dataGridView1.SelectedCells[0].Value.ToString();
                name = dataGridView1.SelectedCells[1].Value.ToString();//；定义两个变量，分别储存所选择学生的学号和姓名
                string sql = "delete from Score where Id='" + id + "'and Name='" + name + "'";//定义变量sql，用来储存Score表中查询的所有符合要求的Id和Name列信息
                Tool tool = new Tool();
                tool.Excute(sql);//定义Tool类型变量tool，并执行sql语句
                Table();//表格刷新

            }
        }

        private void 增加学生成绩ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            增加_修改学生成绩界面 增加_修改学生成绩界面 = new 增加_修改学生成绩界面();
            增加_修改学生成绩界面.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }
    }
}
