﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 成绩查询界面 : Form
    {
        string SID;//定义string变量SID，用来接收参数
        public 成绩查询界面(string sID)
        {
            InitializeComponent();
            SID = sID;//用SID接收sID参数信息
            string sql = "select * from Score where Id='" + SID + "'";
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);
            dr.Read();//定义Tool类型变量，并执行sql语句
            textBox1.Text = dr["Id"].ToString();
            textBox2.Text = dr["Name"].ToString();
            textBox3.Text = dr["Class"].ToString();
            label4.Text = dr["Course1"].ToString();
            label5.Text = dr["Course2"].ToString();
            textBox4.Text = dr["Score1"].ToString();
            textBox5.Text = dr["Score2"].ToString();//将学生的学号、姓名、专业班级、课程名和成绩显示
        }

        private void 成绩查询界面_Load(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }
    }
}
