﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class 选课查看界面 : Form
    {
        string SID;//定义变量SID，用来储存sID信息
        public 选课查看界面(string sID)
        {
            SID = sID;//将sID的信息传递给SID
            InitializeComponent();
            Table();//表格刷新
        }
        public void Table()
        {
            dataGridView1.Rows.Clear();
            string sql = "select* from CourseRecord where sId='"+SID+"'";//在数据库中选课记录表中查询sId列为SID的信息
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);//定义Tool类变量tool，并执行sql储存的sql语句
            while (dr.Read())//如果sql语句执行
            {
                string cID = dr["cId"].ToString();//定义一个变量cID，储存表中cId列信息
                string sql2="select *from Course where Id='"+cID+"'";//定义变量sql2储存课程表格中所有的Id信息
                IDataReader dr2 = tool.read(sql2);
                dr2.Read();//执行sql2语句
                string a, b, c, d;
                a = dr2["Id"].ToString();
                b = dr2["Name"].ToString();
                c = dr2["Credit"].ToString();
                d = dr2["Teacher"].ToString();
                string[] str = { a, b, c, d };//定义变量a，b，c，d，分别用来储存课程表中的编号、姓名、学分、教师的信息
                dataGridView1.Rows.Add(str);//将a，b，c，d的信息按行添加到datagridview中
                dr2.Close();//关闭数据库连接

            }
            dr.Close();//关闭数据库连接
        }


        private void 选课查看界面_Load(object sender, EventArgs e)
        {
            
            label14.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();//时间显示
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("您已完成选课！","信息提示");
            this.Close();//点击选课后提示已完成选课
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            DialogResult r = MessageBox.Show("确定要删除所选课程吗？", "友情提示", MessageBoxButtons.OKCancel);//定义dialogresult类变量r，用来储存信息提示框的反馈信息
            //信息提示框一共有OK和Cancel两种选择结果，询问是否删除所选课程
            if (r == DialogResult.OK)//如果选择了OK
            {   string cID = dataGridView1.SelectedCells[0].Value.ToString();//则定义string类变量cID，用来储存所选择的单元格行信息
                string sql = "delete CourseRecord where sId='" + SID + "'and cId='" + cID + "'";//定义string类变量sql，用来删除课程表中的sId列与cId列信息
                Tool tool = new Tool();
                tool.Excute(sql);//执行sql语句
                Table();//表格刷新
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label14.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();//显示时间
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
