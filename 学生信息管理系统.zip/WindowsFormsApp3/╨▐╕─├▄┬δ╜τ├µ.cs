﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 修改密码界面 : Form
    {
        string SID;//定义string变量SID，用来接收参数
        public 修改密码界面()
        {
            InitializeComponent();
        }
        public 修改密码界面(string sID)//登录、选课、成绩查询、课程查看界面的参数
        {
            InitializeComponent();
            SID = sID;//用SID接收sID参数信息
            string sql = "select *from student where Id='" + SID + "'";//定义string类变量sql，用来储存在数据库里student表中的Id列的信息
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);
            dr.Read();//定义Tool类型变量，并执行sql语句
            textBox1.Text = dr["PassWord"].ToString();//第一个textbox的信息是原密码
            dr.Close();//关闭数据库
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox2.Text = null;
            this.Close();//点击取消后所有信息为空
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "Update student set PassWord='" + textBox2.Text + "'where Id='"+SID+"'";//定义一个string类的变量sql，用来储存更新student表格中的密码列的信息
            Tool tool = new Tool();
            int i=tool.Excute(sql);//执行sql语句，并返回受影响行数
            if(i>0)//如果受影响行数大于0（即sql语句执行）
            {
                MessageBox.Show("修改成功！","友情提示");//提示修改成功
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();//显示时间
        }

        private void 修改密码界面_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();//显示时间
        }
    }
}
