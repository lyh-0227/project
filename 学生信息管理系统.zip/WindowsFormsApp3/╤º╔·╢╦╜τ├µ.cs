﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 学生选课界面 : Form
    {
        string SID;//记录登录学生学号
        public 学生选课界面(string sID)//接收登录界面传来的学生学号信息
        {
            SID = sID;//用SID记录传来的参数sID
            InitializeComponent();
            toolStripStatusLabel1.Text = "欢迎学号为" + SID + "的同学登录选课系统！";//状态栏显示信息
            string sql = "select *from student where Id='" + SID + "'";//定义string类变量sql，用来储存在数据库里student表中的Id列的信息
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);
            dr.Read();//定义Tool类型变量，并执行sql语句
            label5.Text= dr["Id"].ToString();
            label7.Text = dr["Name"].ToString();
            label8.Text = dr["Class"].ToString();//显示当前登录的账号信息
            Table();//datagridview表格信息显示
        }
        public void Table()
        {
            dataGridView1.Rows.Clear();
            string sql = "select* from Course";//从课程表格里搜索全部内容
            Tool tool = new Tool();
            IDataReader dr = tool.read(sql);//定义dr调用tool类读取sql语句中实现内容
            while (dr.Read())//如果执行
            {
                string a, b, c, d;
                a = dr["Id"].ToString();
                b = dr["Name"].ToString();
                c = dr["Credit"].ToString();
                d = dr["Teacher"].ToString();
                string[] str = { a, b, c, d };//定义a，b，c，d四个数组变量储存课程表中的编号、名称、学分、教师信息
                dataGridView1.Rows.Add(str);//按行添加到datagridview中并显示

            }
            dr.Close();//关闭连接
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();//显示当前时间
        }

        private void 学生选课界面_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
            label6.Text = DateTime.Now.ToString("今天是yyyy年MM月dd日");
            timer2.Start();//状态栏显示当前时间，并在界面上提示
        }

        private void 学生选课ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 选择这门课ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string cID = dataGridView1.SelectedCells[0].Value.ToString();//获取选中的课程号
            string sql1 = "select * from  CourseRecord where sId='"+SID+"'and cId='"+cID+"'";//在选课记录表格中寻找选中课程的信息并用sql1变量保存
            Tool tool = new Tool();
            IDataReader dc = tool.read(sql1);//定义dc并执行sql1语句（目的是为了查看所选中的信息是否在课程记录表中存在）
            if (!dc.Read())//如果没有执行（即信息不存在于课程记录表中）
            {
             string sql = "Insert into CourseRecord values('" + SID + "','" + cID + "') ";//将选中课程信息添加到课程记录表中
             int i = tool.Excute(sql);//执行sql语句，并返回受影响行数
            if (i > 0)//如果受影响行数不为零
            {
                MessageBox.Show("选课成功！", "友情提示");//选课成功
            }
            }
            else
            {
                MessageBox.Show("禁止重复选课！","友情提示");
            }//如果执行过则提示重复选课

          

        }

        private void 查看所选课程ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            选课查看界面 选课查看界面 = new 选课查看界面(SID);
            选课查看界面.ShowDialog();
            this.Hide();//将登录界面传来并通过SID保存的参数sID传递给选课查看界面并运行选课查看界面
        }

      
        private void timer2_Tick(object sender, EventArgs e)
        {
            label6.Text = DateTime.Now.ToString("今天是yyyy年MM月dd日");
            timer2.Start();//状态栏显示当前时间
        }

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            修改密码界面 修改密码界面 = new 修改密码界面(SID);
            修改密码界面.ShowDialog();//将登录界面传来并通过SID保存的参数sID传递给修改密码界面并运行修改密码界面
        }

       

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
             this.Close();//点击退出则结束程序
        }

        private void 成绩查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            成绩查询界面 成绩查询界面 = new 成绩查询界面(SID);
            成绩查询界面.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
