﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 登录界面 : Form
    {
        public 登录界面()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");//显示当前时间
            timer2.Start();//第二个timer开始运行

        }   
        private void timer1_Tick(object sender, EventArgs e)
        {

            if (pictureBox1.Location.X < 150)
            {
                pictureBox1.Location = new Point(pictureBox1.Location.X + 10, pictureBox1.Location.Y);//当图片位置的横坐标小于150，则图片以时间间隔向右移动十个单位距离
                label4.Text = "正在登录......";
            }
            else
            {       timer1.Stop();//否则第一个计时器停止计时
                    label4.Text = "登录成功";
                if (comboBox1.Text.Equals("学生"))//如果登录的是学生
                {   string sql = "select * from student where Name='" + textBox1.Text + "'and PassWord='" + textBox2.Text + "'";//则在学生表格中查找所有姓名为第一个文本框，密码为第二个文本框的所有学生信息，并用变量sql记录
                    Tool tool= new Tool();
                    IDataReader dr = tool.read(sql);
                    dr.Read();//执行sql语句，读取学生信息内容
                    string sID=dr["Id"].ToString();//用sID记录学生的学号
                    学生选课界面 学生选课界面 = new 学生选课界面(sID);
                    学生选课界面.ShowDialog();//将学生信息传递给学生界面，并运行学生界面
                    this.Close();
                }
                else
                {
                    if (comboBox1.Text.Equals("教师"))
                    {
                        
                        教师端界面 教师端界面 = new 教师端界面();
                        教师端界面.ShowDialog();
                        this.Close();//如果是教师登录，则运行教师界面
                    }
                    
                }
                
            }
        }
    
        //登录
        private void button1_Click(object sender, EventArgs e)
        {
            if (login())
            {
                timer1.Start();//启动计时器，图片移动
                textBox1.Visible = false;
                textBox2.Visible = false;
                comboBox1.Visible = false;
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                label5.Visible = false;


            }//如果登录函数运行，则所有控件均不可见
        }
        private bool login()
        {
            if (textBox1.Text.Equals("") || textBox2.Text.Equals("") || comboBox1.Text.Equals(""))
            {
                MessageBox.Show("您的输入不完整！", "友情提示");
                return false;//如果所有信息为空，则信息框提示输入不完整
            }
            if (comboBox1.Text.Equals("学生"))//如果是学生登录
            {
                string sql = "select * from student where Name='" + textBox1.Text + "'and PassWord='" + textBox2.Text + "'";//在数据库里寻找名字与密码相匹配的信息，并用sql储存
                Tool tool = new Tool();
                IDataReader dr = tool.read(sql);//在数据库里执行sql语句并返回给界面
                if (dr.Read())//如果sql语句可以执行（即信息在数据库里存在）
                {
                    MessageBox.Show("登录成功！", "友情提示");
                    return true;//登录成功并返回真值
                }
                else
                {
                    MessageBox.Show("用户名或密码不正确！", "友情提示");
                    return false;//否则无法登录并返回假值
                }

            }
            if (comboBox1.Text.Equals("教师"))
            {
                string sql = "select * from teacher where Name='" + textBox1.Text + "'and PassWord='" + textBox2.Text + "'";
                Tool tool = new Tool();
                IDataReader dr = tool.read(sql);
                if (dr.Read())
                {
                    MessageBox.Show("登录成功！", "友情提示");
                    return true;
                }
                else
                {
                    MessageBox.Show("用户名或密码不正确！", "友情提示");
                    return false;
                }
            }//逻辑关系同理于学生登录过程，搜索表格为教师信息表
            
            return false;//如果所有的登录条件均不符合，则返回假值
           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox2.Text = null;
            comboBox1.Text = null;
            this.Close();//鼠标点击时所有信息均为空
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

     

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer2.Start();//实现时间运行与显示功能
        }

        private void button3_Click(object sender, EventArgs e)
        {
            注册界面 注册界面 = new 注册界面();
            注册界面.ShowDialog();
            this.Hide();
        }
    }
}
