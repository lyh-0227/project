﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class 注册界面 : Form
    {
        public 注册界面()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Text = null;
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text=="")
            {
                MessageBox.Show("请您先选择身份！","友情提示");
            }

            else if(comboBox1.Text=="学生")//如果是学生注册，则对学生的表格进行操作
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
                {
                    MessageBox.Show("您输入的信息不完整！","温馨提示");//如果注册信息为空，则提示不完整
                }
                else
                {
                    string sql = "Insert into student values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox4.Text + "')";
                    //否则定义string类变量sql，用来执行插入的数据库sql语句（插入的信息即为五个textbox中的文本内容 
                    Tool tool = new Tool();
                    int i = tool.Excute(sql);//定义了一个Tool类的变量tool，并执行sql语句，定义变量i，用来储存返回的受影响行数
                   if (i > 0)//如果受影响行数大于0
                   {
                     MessageBox.Show("注册成功！", "友情提示");
                     comboBox1.Text = "";
                     textBox1.Text = "";
                     textBox2.Text = "";
                     textBox3.Text = "";
                     textBox4.Text = "";
                     textBox5.Text = "";
                     textBox6.Text = "";//提示增加成功，并将已完成增加操作的textbox清空
                   }

                }
               

            }
            else if(comboBox1.Text=="教师")//如果是教师注册
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox4.Text == "" || textBox7.Text == "" )
                {
                    MessageBox.Show("您输入的信息不完整！", "温馨提示");//如果注册信息为空，则提示不完整
                }

                else
                {
                   string sql = "Insert into teacher values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox4.Text + "','" + textBox7.Text + "')";
                   //否则定义string类变量sql，用来执行插入的数据库sql语句（插入的信息即为五个textbox中的文本内容 
                   Tool tool = new Tool();
                   int i = tool.Excute(sql);//定义了一个Tool类的变量tool，并执行sql语句，定义变量i，用来储存返回的受影响行数
                   if (i > 0)//如果受影响行数大于0
                   {
                     MessageBox.Show("注册成功！", "友情提示");
                     comboBox1.Text = "";
                     textBox1.Text = "";
                     textBox2.Text = "";
                     textBox4.Text = "";
                     textBox7.Text = "";//提示增加成功，并将已完成增加操作的textbox清空
                   }
                }
               

            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text=="学生")//如果是学生注册，则显示学生注册需要填写的信息文本框
            {
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = false;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = false;

            }
            else if(comboBox1.Text=="教师")//如果是教师注册，则显示教师注册需要填写的信息文本框
            {
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label7.Visible = true;
                label8.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = true;
                textBox5.Visible = false;
                textBox6.Visible = false;
                textBox7.Visible = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void 注册界面_Load(object sender, EventArgs e)
        {
            label9.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label9.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ");
            timer1.Start();
        }
    }
}
