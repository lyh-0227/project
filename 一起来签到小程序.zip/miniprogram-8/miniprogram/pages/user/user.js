// pages/user/user.js
Page({
    
    //保存用户信息
    data: {
      // avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0',
      userinfo:{},
      nickName:{},
      
      
 
  
    },
  
    //页面显示
    onShow(){
      
      //将缓存中的数据取出来，并将数据赋值给变量，让页面显示
      const userinfo=wx.getStorageSync("userinfo");
      const nickName=wx.getStorageSync("nickName");
      this.setData({
        userinfo:userinfo,
        nickName:nickName,
        
        
      });

      
      
    },

    test(e){
      console.log(e);
    },
    
    handleExit(){
      this.setData({
        userinfo:{},
        nickName:{}
      });

      wx.clearStorageSync();
      wx.showToast({
        title: '退出成功',
        icon: 'success',
        
        duration: 1500,
        mask: true,
        success: ()=>{
          wx.reLaunch({
            url: '/pages/index/index'
            
          });
        }
      });
    },

    handlePhoneCall(){
      wx.showToast({
        title: '正在跳转',
        icon: 'loading',
        duration: 1500,
        mask: true,
        success: ()=>{
          
          wx.makePhoneCall({
            phoneNumber: '400-999-9999',
          });

        },
      });
    },

    //点击分享，个人微信小程序账号点击分享后无分享权限
    handleShare(){
      wx.showActionSheet({
        itemList: [
          '分享到朋友圈','分享到企业微信','分享到手机QQ','分享到QQ空间','分享到微博'
        ],
        itemColor: '#000000',
        success: (result)=>{
          
        },
        fail: ()=>{},
        complete: ()=>{}
      });
    },

    handleShutDown(){
      wx.showModal({
        title: '提示',
        content: '您确定要退出吗？',
        showCancel: true,
        cancelText: '取消',
        cancelColor: '#000000',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        success: (result) => {
          if(result.confirm){
            wx.exitMiniProgram();
          } 
          else{
            
          }
        },
        fail: ()=>{},
        complete: ()=>{}
      });
      
    },
   
    // onChooseAvatar(e) {
    //   const { avatarUrl } = e.detail 
    //   this.setData({
    //     avatarUrl,
        
    //   })
    // }

  })

 
