const db = wx.cloud.database()
Page({

  
  /**
   * 页面的初始数据
   */
  data: {
    swiper:[],
    userinfo:{},
    nickName:{},
    clicktime1:0,
    clicktime2:0,
    clicktime3:0,
    usetime1:0,
    usetime2:0,
    usetime3:0

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 查询swiper集合

    // 1、选择操作的swiper集合
    const swiperCollection = db.collection('swiper')

    // 特别注意：需要在云开发控制台提前创建swiper集合，同时还需要设置数据权限为所有用户可读，仅创建者可读写

    // 2、查询集合数据
    swiperCollection.get().then(res => {
      //console.log(res)
      //更新轮播图数据
      this.setData({
        swiper: res.data
      })
    }).catch(err => {
      console.log(err)
    })

    const signCollection=db.collection('signrecord')
    signCollection.where({
      id:1
    }).get()
    .then(res=>{
      //console.log(res.data.length);
      this.setData({
        usetime1:res.data.length
      })
    })

    signCollection.where({
      id:2
    }).get()
    .then(res=>{
      //console.log(res.data.length);
      this.setData({
        usetime2:res.data.length
      })
    })

    signCollection.where({
      id:3
    }).get()
    .then(res=>{
      //console.log(res.data.length);
      this.setData({
        usetime3:res.data.length
      })
    })
    
 
    
    


  },



  sign(e){
    console.log(e);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const userinfo=wx.getStorageSync("userinfo");
    const nickName=wx.getStorageSync("nickName"); 
    //console.log(userinfo)
    //console.log(nickName)
    this.setData({
      userinfo:userinfo,
      nickName:nickName,
      
      
    });


    
  },

  clickdata1(){
    var clicktime1=this.data.clicktime1+1
    this.setData({
      clicktime1
    })
  },

  clickdata2(){
    var clicktime2=this.data.clicktime2+1
    this.setData({
      clicktime2
    })
  },
  clickdata3(){
    var clicktime3=this.data.clicktime3+1
    this.setData({
      clicktime3
    })
  },



  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})