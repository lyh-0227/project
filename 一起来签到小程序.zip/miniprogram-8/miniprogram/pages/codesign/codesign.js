const db=wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    startdate: '请选择',
    enddate:"请选择",
    starttime: '请选择',
    endtime: '请选择',
    code:"点击生成",
    name:"",
    year1:"",
    month1:"",
    day1:"",
    year2:"",
    month2:"",
    day2:"",
    hour1:"",
    minute1:"",
    hour2:"",
    minute2:"",
    selectStartDate:"",
    selectEndDate:"",
    selectStartTime:"",
    selectEndTime:""
  },
  TimeId:-1,

  bindDateChange1(e) {
    this.setData({
      startdate: e.detail.value
    })
    var year1=this.data.startdate.slice(0,4);
    var month1=this.data.startdate.slice(5,7);
    var day1=this.data.startdate.slice(8,10);
    var selectStartDate=year1+month1+day1;
    selectStartDate=parseInt(selectStartDate);
    this.setData({
      year1,
      month1,
      day1,
      selectStartDate
    })
    //console.log(this.data.selectStartDate)
  },
  bindDateChange2(e) {
    
    this.setData({
      enddate: e.detail.value
    })
    var year2=this.data.enddate.slice(0,4);
    var month2=this.data.enddate.slice(5,7);
    var day2=this.data.enddate.slice(8,10);
    var selectEndDate=year2+month2+day2;
    selectEndDate=parseInt(selectEndDate);
    this.setData({
      year2,
      month2,
      day2,
      selectEndDate
    })
    //console.log(this.data.selectEndDate)
  },
  bindTimeChange1(e) {
    
    this.setData({
      starttime: e.detail.value
    })
    var hour1=this.data.starttime.slice(0,2)<10?"0"+(this.data.starttime.slice(0,2)):this.data.starttime.slice(0,2);
    var minute1=this.data.starttime.slice(3,5);
    var selectStartTime=hour1+minute1;
    selectStartTime=parseInt(selectStartTime);
    this.setData({
      hour1,
      minute1,
      selectStartTime
    })
    //console.log(this.data.selectStartTime)
  },
  bindTimeChange2(e) {
    
    this.setData({
      endtime: e.detail.value
    })
    var hour2=this.data.endtime.slice(0,2)<10?"0"+(this.data.endtime.slice(0,2)):this.data.endtime.slice(0,2);
    var minute2=this.data.endtime.slice(3,5);
    var selectEndTime=hour2+minute2;
    selectEndTime=parseInt(selectEndTime);
    this.setData({
      hour2,
      minute2,
      selectEndTime
    })
    //console.log(this.data.selectEndTime)
  },

  getUserInput(e){
    const name=e.detail.value;
    if(!name.trim()){
      return;
    }
    this.setData({
      name
    })
    clearTimeout(this.TimeId);
    this.TimeId=setTimeout(() => {
      this.setData({
        name
      })
    },1000);
    //console.log(name);
  },

  creatCode(){
    let code="";
    for(var i=0;i<6;i++)
    {
      code+=Math.floor(Math.random()*10);
    }
    console.log(code);
    this.setData({
      code:code
    })
  },

  creatSign(){
    var time=new Date();
    var currentYear=time.getFullYear();
    var currentMonth=time.getMonth()+1<10?"0"+(time.getMonth()+1):time.getMonth()+1;
    var currentDay=time.getDate()<10?"0"+(time.getDate()):time.getDate();
    var currentHour=time.getHours()<10?"0"+(time.getHours()):time.getHours();
    var currentMinute=time.getMinutes()<10?"0"+(time.getMinutes()):time.getMinutes();
    var currentDate=currentYear.toString()+"-"+currentMonth.toString()+"-"+currentDay.toString()
    var currentTime=currentHour.toString()+":"+currentMinute.toString();
    //console.log(currentDate);
    //console.log(currentTime);
    const signCollection = db.collection('signrecord');

    if (this.data.name==""||this.data.startdate=="请选择"||this.data.enddate=="请选择"||this.data.starttime=="请选择"||this.data.endtime=="请选择"||this.data.code=="点击生成") {
      wx.showToast({
        title: '信息不全',
        icon: 'error',
        duration: 1500,
        mask: true,
        success: (result)=>{
          
        },
      });
    }
    else if (this.data.startdate<currentDate){
      wx.showToast({
        title: '日期时间不正确',
        icon:'none',
        duration: 1500,
        mask: true,
      });

    }
    else if (this.data.enddate<currentDate){
      wx.showToast({
        title: '日期时间不正确',
        icon:'none',
        duration: 1500,
        mask: true,
      });

    }
    else if (this.data.enddate<this.data.startdate){
      wx.showToast({
        title: '日期时间不正确',
        icon:'none',
        duration: 1500,
        mask: true,
      });

    }
    else if (this.data.endtime<this.data.starttime){
      wx.showToast({
        title: '日期时间不正确',
        icon:'none',
        duration: 1500,
        mask: true,
      });

    }
    else if(this.data.name.length>10){
      wx.showToast({
        title: '名称最长为10个字符',
        icon: 'none',
        duration: 1500,
        mask: true,
      });

    }
    else if((this.data.startdate==currentDate)&&(this.data.enddate==currentDate)){
      if((this.data.starttime<currentTime)||(this.data.endtime<currentTime)){
         wx.showToast({
        title: '日期时间不正确',
        icon:'none',
        duration: 1500,
        mask: true,
        });
      }
      else{
        signCollection.add({
          data:{
            name:this.data.name,
            selectStartDate:this.data.startdate,
            selectEndDate:this.data.enddate,
            selectStartTime:this.data.starttime,
            selectEndTime:this.data.endtime,
            code:this.data.code,
            id:3,
            issigned:"未签到"
  
          }
        }).then(res=>{
          console.log("添加成功",res);
          wx.showToast({
            title: '创建成功',
            icon: 'success',
            duration: 1500,
            mask: true,
            success: (result)=>{
              this.setData({
                name:"请输入名称",
                startdate:"请选择",
                enddate:"请选择",
                starttime:"请选择",
                endtime:"请选择",
                code:"点击生成"
              })
            
            
            },
          
          });
         
        }).catch(err=>{
          console.log("添加失败",err);
        })
      }
     
    }
    
    else{
      
      signCollection.add({
        data:{
          name:this.data.name,
          selectStartDate:this.data.startdate,
          selectEndDate:this.data.enddate,
          selectStartTime:this.data.starttime,
          selectEndTime:this.data.endtime,
          code:this.data.code,
          id:3,
          issigned:"未签到"

        }
      }).then(res=>{
        console.log("添加成功",res);
        wx.showToast({
          title: '创建成功',
          icon: 'success',
          duration: 1500,
          mask: true,
          success: (result)=>{
            this.setData({
              name:"请输入名称",
              startdate:"请选择",
              enddate:"请选择",
              starttime:"请选择",
              endtime:"请选择",
              code:"点击生成"
            })
          
          
          },
        
        });
       
      }).catch(err=>{
        console.log("添加失败",err);
      })

      
    }
  },


  
})
