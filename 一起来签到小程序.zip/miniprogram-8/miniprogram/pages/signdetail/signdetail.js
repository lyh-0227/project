const db = wx.cloud.database()
var that
Page({
  data:{

    //数据库中读取的id值对应的签到所有信息
    signDetail:[],

    //传递过来的签到种类，1为普通签到，2为定位签到，3为密码签到
    id:"",
    //传递过来的签到记录的id
    _id:"",
    codeinput:"",
    latitude:0,
    longitude:0,
    userlocation:"点击获取",
    
  },
  onLoad:function(options){
    // 生命周期函数--监听页面加载
    //console.log(options)
    that=this
    var _id=options.id;//传递过来的签到记录的id
    const signCollection = db.collection('signrecord')
    signCollection
      .where({
        _id:_id
      })
      .get()
      .then(res=>{
        //console.log(res.data[0])
        
        this.setData({
          signDetail:res.data,
          id:res.data[0].id,
          _id
        })
        
        // console.log(this.data._id);
        // console.log(this.data.signDetail[0]);
        // console.log(this.data.id);
      })
    

  },
  getLocation(){
    wx.openSetting({
      withSubscriptions: true,
      success:(res)=>{
        //console.log(res.authSetting['scope.userLocation']);
        if(res.authSetting['scope.userLocation']==true){
          wx.authorize({
            scope: 'scope.userLocation',
            success(){
              wx.getLocation({
                type: 'wgs84',
                success: (res)=>{
                  var latitude=res.latitude
                  var longitude=res.longitude
                  console.log(latitude,longitude);
                  wx.request({
                    url: 'https://apis.map.qq.com/ws/geocoder/v1/?location='+latitude+','+longitude+'&key=RNWBZ-LIZLD-AFP4P-PPOA7-IFOB6-ZTBYS',
                    header: {'content-type':'application/json'},
                    method: 'GET',
                    dataType: 'json',
                    responseType: 'text',
                    success: (res)=>{
                      //console.log(res)
                      that.setData({
                        latitude,
                        longitude,
                        userlocation:res.data.result.formatted_addresses.recommend
                        
                      })
                      //console.log(that.data.latitude,that.data.longitude,that.data.userlocation)
                    },
                    fail: ()=>{
                      wx.showToast({
                        title: '请打开位置权限以便获取您当前位置',
                        icon:'none'
                      })
                    },
                    complete: ()=>{}
                  });
                },
                fail:()=>{
                  wx.showToast({
                    title: '请打开位置权限以便获取您当前位置',
                    icon:'none'
                  })
                }
              });
            },
            fail(){
              wx.showToast({
                title: '需要授权',
              })
            }
          })
        }
        else{
          wx.showToast({
            title: '您需要授权才可以获取您的地理位置',
            icon:'none'
          })
        }
      }
    })
    
   
  },

  signcode(e){
    var codeinput=e.detail.value;
    this.setData({
      codeinput
    })
    //console.log(this.data.codeinput);
  },

  sign(){
    
    //获取当前系统的日期和时间
    var time=new Date();
    var currentYear=time.getFullYear();
    var currentMonth=time.getMonth()+1<10?"0"+(time.getMonth()+1):time.getMonth()+1;
    var currentDay=time.getDate()<10?"0"+(time.getDate()):time.getDate();
    var currentHour=time.getHours()<10?"0"+(time.getHours()):time.getHours();
    var currentMinute=time.getMinutes()<10?"0"+(time.getMinutes()):time.getMinutes();
    var currentDate=currentYear.toString()+"-"+currentMonth.toString()+"-"+currentDay.toString()
    var currentTime=currentHour.toString()+":"+currentMinute.toString();
    //console.log(this.data.latitude,this.data.longitude,this.data.userlocation)

    //获取签到信息中的日期和时间
    var startDate=this.data.signDetail[0].selectStartDate;
    var endDate=this.data.signDetail[0].selectEndDate;
    var startTime=this.data.signDetail[0].selectStartTime;
    var endTime=this.data.signDetail[0].selectEndTime;
    //console.log(startDate,endDate,startTime,endTime);

    //获取签到种类
    var type=this.data.signDetail[0].id;
    //console.log(type);

    //获取签到状态
    var status=this.data.signDetail[0].issigned;
    //console.log(status)

    //获取签到位置信息
    var location=this.data.signDetail[0].mapName;
    var signlatitude=this.data.signDetail[0].latitude;
    var signlongitude=this.data.signDetail[0].longitude;
    //console.log(location,signlatitude,signlongitude);

    //获取签到签到码
    var code=this.data.signDetail[0].code;

    if (type==1){

      if(status=="未签到"){

        if((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>=startTime)&&(currentTime<=endTime)){

          wx.showToast({
            title: '签到成功',
            icon: 'success',
            duration: 1500,
            mask: true,
            success: (result)=>{

              //将issigned属性变为true，表示已签到
              const signCollection = db.collection('signrecord')
              signCollection.where({
                _id:this.data._id
              }).update({
                data:{
                  issigned:"已签到"
                }
              }).then(res=>{
                
                console.log("更新成功")
                wx.navigateBack({
                  delta: 1
                });
              }).catch(err=>{
                console.log(err)
              })
              
            },
            fail: ()=>{},
            complete: ()=>{}
          });

        }
        
        if((currentDate<startDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime<startTime))){
          wx.showToast({
            title: '签到未开始',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              setTimeout(()=>{
                wx.navigateBack({
                  delta: 1
                });
              },2000)
            }
          })

        }

        if((currentDate>endDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>endTime))){
          wx.showToast({
            title: '签到已过期',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              const signCollection = db.collection('signrecord')
              signCollection.where({
                _id:this.data._id
              }).update({
                data:{
                  issigned:"已过期"
                }
              }).then(res=>{
                
                console.log("更新成功")
                wx.navigateBack({
                  delta: 1
                });
              }).catch(err=>{
                console.log(err)
              })
              
            }
          })
        }
        
      }

      if(status=="已签到"){
        wx.showToast({
          title: '请勿重复签到',
          icon: 'none',
          duration: 1500,
          mask: true,
          success:(result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          }
        });
      }

      if(status=="已过期"){
        wx.showToast({
          title: '签到已过期',
          icon: 'none',
          duration: 1500,
          mask: true,
          success: (result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          },

        });
      }
      

    }

    if(type==2){
      if(status=="未签到"){

        if((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>=startTime)&&(currentTime<=endTime)){
          
          if((this.data.latitude>=signlatitude-0.01)&&(this.data.latitude<=signlatitude+0.01)&&(this.data.longitude>=signlongitude-0.01)&&(this.data.longitude<=signlongitude+0.01)){

            wx.showToast({
              title: '签到成功',
              icon: 'success',
              duration: 1500,
              mask: true,
              success: (result)=>{
  
                //将issigned属性变为true，表示已签到
                const signCollection = db.collection('signrecord')
                signCollection.where({
                  _id:this.data._id
                }).update({
                  data:{
                    issigned:"已签到"
                  }
                }).then(res=>{
                  
                  console.log("更新成功")
                  wx.navigateBack({
                    delta: 1
                  });
                }).catch(err=>{
                  console.log(err)
                })
                
              },
              fail: ()=>{},
              complete: ()=>{}
            });
          
          }
          else{
            wx.showToast({
              title: '不在可签到范围内',
              icon: 'none',
              duration: 1500,
              mask: true,
            });
          }

        }
        
        if((currentDate<startDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime<startTime))){
          wx.showToast({
            title: '签到未开始',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              setTimeout(()=>{
                wx.navigateBack({
                  delta: 1
                });
              },2000)
            }
          })

        }

        if((currentDate>endDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>endTime))){
          wx.showToast({
            title: '签到已过期',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              const signCollection = db.collection('signrecord')
              signCollection.where({
                _id:this.data._id
              }).update({
                data:{
                  issigned:"已过期"
                }
              }).then(res=>{
                
                console.log("更新成功")
                wx.navigateBack({
                  delta: 1
                });
              }).catch(err=>{
                console.log(err)
              })
              
            }
          })
        }
        
      }
      if(status=="已签到"){
        wx.showToast({
          title: '请勿重复签到',
          icon: 'none',
          duration: 1500,
          mask: true,
          success:(result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          }
        });
      }
      if(status=="已过期"){
        wx.showToast({
          title: '签到已过期',
          icon: 'none',
          duration: 1500,
          mask: true,
          success: (result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          },

        });
      }

    }

    if(type==3){
      if(status=="未签到"){
        if((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>=startTime)&&(currentTime<=endTime)){
          if(this.data.codeinput==code){
            wx.showToast({
              title: '签到成功',
              icon: 'success',
              duration: 1500,
              mask: true,
              success: (result)=>{
  
                //将issigned属性变为true，表示已签到
                const signCollection = db.collection('signrecord')
                signCollection.where({
                  _id:this.data._id
                }).update({
                  data:{
                    issigned:"已签到"
                  }
                }).then(res=>{
                  
                  console.log("更新成功")
                  wx.navigateBack({
                    delta: 1
                  });
                }).catch(err=>{
                  console.log(err)
                })
                
              },
              fail: ()=>{},
              complete: ()=>{}
            });
          }
          else{
            wx.showToast({
              title: '签到码不正确',
              icon: 'none',
              duration: 1500,
              mask: true,
            });
          }
        }

        if((currentDate<startDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime<startTime))){
          wx.showToast({
            title: '签到未开始',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              setTimeout(()=>{
                wx.navigateBack({
                  delta: 1
                });
              },2000)
            }
          })

        }
        if((currentDate>endDate)||((currentDate>=startDate)&&(currentDate<=endDate)&&(currentTime>endTime))){
          wx.showToast({
            title: '签到已过期',
            icon: 'none',
            duration: 1500,
            mask: true,
            success:(result)=>{
              const signCollection = db.collection('signrecord')
              signCollection.where({
                _id:this.data._id
              }).update({
                data:{
                  issigned:"已过期"
                }
              }).then(res=>{
                
                //console.log("更新成功")
                wx.navigateBack({
                  delta: 1
                });
              }).catch(err=>{
                console.log(err)
              })
              
            }
          })
        }

        
      }
      if(status=="已签到"){
        wx.showToast({
          title: '请勿重复签到',
          icon: 'none',
          duration: 1500,
          mask: true,
          success:(result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          }
        });
      }
      if(status=="已过期"){
        wx.showToast({
          title: '签到已过期',
          icon: 'none',
          duration: 1500,
          mask: true,
          success: (result)=>{
            setTimeout(()=>{
              wx.navigateBack({
                delta: 1
              });
            },2000)
          },

        });
      }
    }
    
  },

  onReady:function(){
    // 生命周期函数--监听页面初次渲染完成
    
  },
  onShow:function(){
    // 生命周期函数--监听页面显示

    
  },
  onHide:function(){
    // 生命周期函数--监听页面隐藏
    
  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载
    
  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
    
  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数
    
  },
  onShareAppMessage: function() {
    // 用户点击右上角分享
  }
})