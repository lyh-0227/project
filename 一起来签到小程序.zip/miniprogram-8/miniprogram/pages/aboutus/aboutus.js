Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },
  handleUpdate(){
    wx.showToast({
      title: '暂无更新!',
      icon: 'none',
      duration: 1500,
      mask: true,
    });
  }


})