// pages/changesigndetail/changesigndetail.js
//Page Object
const db = wx.cloud.database()
Page({
  data: {
    signDetail:[],
     //传递过来的签到种类，1为普通签到，2为定位签到，3为密码签到
     id:"",
     //传递过来的签到记录的id
     _id:"",
    startdate: '请选择',
    enddate:"请选择",
    starttime: '请选择',
    endtime: '请选择',
    mapName:"请选择",
    longitude:0,
    latitude:0,
    code:"点击生成",
    name:"",
    year1:"",
    month1:"",
    day1:"",
    year2:"",
    month2:"",
    day2:"",
    hour1:"",
    minute1:"",
    hour2:"",
    minute2:"",
    selectStartDate:"",
    selectEndDate:"",
    selectStartTime:"",
    selectEndTime:""
    
  },
  TimeId:-1,

  bindDateChange1(e) {
   
    this.setData({
      startdate: e.detail.value
    })
    //console.log(this.data.startdate);

    var year1=this.data.startdate.slice(0,4);
    var month1=this.data.startdate.slice(5,7);
    var day1=this.data.startdate.slice(8,10);
    var selectStartDate=year1+month1+day1;
    selectStartDate=parseInt(selectStartDate);
    this.setData({
      year1,
      month1,
      day1,
      selectStartDate
    })
    //console.log(this.data.selectStartDate)
  },
  bindDateChange2(e) {
    
    this.setData({
      enddate: e.detail.value
    })
    var year2=this.data.enddate.slice(0,4);
    var month2=this.data.enddate.slice(5,7);
    var day2=this.data.enddate.slice(8,10);
    var selectEndDate=year2+month2+day2;
    selectEndDate=parseInt(selectEndDate);
    this.setData({
      year2,
      month2,
      day2,
      selectEndDate
    })
    //console.log(this.data.selectEndDate)
  },
  bindTimeChange1(e) {
    
    this.setData({
      starttime: e.detail.value
    })
    var hour1=this.data.starttime.slice(0,2)<10?"0"+(this.data.starttime.slice(0,2)):this.data.starttime.slice(0,2);
    var minute1=this.data.starttime.slice(3,5);
    var selectStartTime=hour1+minute1;
    selectStartTime=parseInt(selectStartTime);
    this.setData({
      hour1,
      minute1,
      selectStartTime
    })
    //console.log(this.data.selectStartTime)
  },
  bindTimeChange2(e) {
    
    this.setData({
      endtime: e.detail.value
    })
    var hour2=this.data.endtime.slice(0,2)<10?"0"+(this.data.endtime.slice(0,2)):this.data.endtime.slice(0,2);
    var minute2=this.data.endtime.slice(3,5);
    var selectEndTime=hour2+minute2;
    selectEndTime=parseInt(selectEndTime);
    this.setData({
      hour2,
      minute2,
      selectEndTime
    })
    //console.log(this.data.selectEndTime)
  },

  //options(Object)
  onLoad: function(options){
    //console.log(options);
    var _id=options.id;
    const signCollection = db.collection('signrecord')
    signCollection
      .where({
        _id:_id
      })
      .get()
      .then(res=>{
        //console.log(res.data[0])
        
        this.setData({
          signDetail:res.data,
          id:res.data[0].id,
          _id
        })
        
        // console.log(this.data._id);
        // console.log(this.data.signDetail[0]);
        // console.log(this.data.id);
      })
  },

  getUserInput(e){
    const name=e.detail.value;
    if(!name.trim()){
      return;
    }
    this.setData({
      name
    })
    clearTimeout(this.TimeId);
    this.TimeId=setTimeout(() => {
      this.setData({
        name
      })
    },1000);
    //console.log(this.data.name);
  },

  chooseLocation(){
    //let that=this
    wx.chooseLocation({
      success: (result)=>{
        //console.log(result)
        this.setData({
          mapName:result.name,
          latitude:result.latitude,
          longitude:result.longitude
        })
        if (result.name==""){
          result.name="未选择"
          this.setData({
            mapName:result.name
          })
        }
      },
      fail: ()=>{},
      complete: ()=>{}
    });
 
    //console.log(this.data.mapName);
  },

  creatCode(){
    let code="";
    for(var i=0;i<6;i++)
    {
      code+=Math.floor(Math.random()*10);
    }
    console.log(code);
    this.setData({
      code:code
    })
  },

  changesigndetail(){
    //获取当前日期和时间
    var time=new Date();
    var currentYear=time.getFullYear();
    var currentMonth=time.getMonth()+1<10?"0"+(time.getMonth()+1):time.getMonth()+1;
    var currentDay=time.getDate()<10?"0"+(time.getDate()):time.getDate();
    var currentHour=time.getHours()<10?"0"+(time.getHours()):time.getHours();
    var currentMinute=time.getMinutes()<10?"0"+(time.getMinutes()):time.getMinutes();
    var currentDate=currentYear.toString()+"-"+currentMonth.toString()+"-"+currentDay.toString()
    var currentTime=currentHour.toString()+":"+currentMinute.toString();
    const signCollection = db.collection('signrecord');

    //修改普通签到
    if(this.data.id==1){
      if (this.data.name==""||this.data.startdate=="请选择"||this.data.enddate=="请选择"||this.data.starttime=="请选择"||this.data.endtime=="请选择") {
        wx.showToast({
          title: '信息不全',
          icon: 'error',
          duration: 1500,
          mask: true,
          success: (result)=>{
            
          },
        });
      }
      else if (this.data.startdate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<this.data.startdate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.endtime<this.data.starttime){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if(this.data.name.length>10){
        wx.showToast({
          title: '名称最长为10个字符',
          icon: 'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if((this.data.startdate==currentDate)&&(this.data.enddate==currentDate)){
        if((this.data.starttime<currentTime)||(this.data.endtime<currentTime)){
           wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
          });
        }
        else{
          signCollection.where({
            _id:this.data._id
          }).update({
            data:{
              name:this.data.name,
              selectStartDate:this.data.startdate,
              selectEndDate:this.data.enddate,
              selectStartTime:this.data.starttime,
              selectEndTime:this.data.endtime,
              id:1,
              issigned:"未签到"
            }
          }).then(res=>{
            console.log("更新成功")
            wx.showToast({
              title: '修改成功',
              icon: 'success',
              duration: 1500,
              mask: true,
              success: (result)=>{
                this.setData({
                  name:"请输入名称",
                  startdate:"请选择",
                  enddate:"请选择",
                  starttime:"请选择",
                  endtime:"请选择"
                })
              
              
              },
            
            });
          }).catch(err=>{
            console.log("更新失败")
          })
    
        }
      } 
      else{
        signCollection.where({
          _id:this.data._id
        }).update({
          data:{
            name:this.data.name,
            selectStartDate:this.data.startdate,
            selectEndDate:this.data.enddate,
            selectStartTime:this.data.starttime,
            selectEndTime:this.data.endtime,
            id:1,
            issigned:"未签到"
          }
        }).then(res=>{
          console.log("更新成功")
          wx.showToast({
            title: '修改成功',
            icon: 'success',
            duration: 1500,
            mask: true,
            success: (result)=>{
              this.setData({
                name:"请输入名称",
                startdate:"请选择",
                enddate:"请选择",
                starttime:"请选择",
                endtime:"请选择"
              })
            
            
            },
          
          });
        }).catch(err=>{
          console.log("更新失败")
        })
      }
    }

    //修改定位签到
    if(this.data.id==2){
      if (this.data.name==""||this.data.startdate=="请选择"||this.data.enddate=="请选择"||this.data.starttime=="请选择"||this.data.endtime=="请选择"||this.data.mapName=="请选择") {
        wx.showToast({
          title: '信息不全',
          icon: 'error',
          duration: 1500,
          mask: true,
          success: (result)=>{
            
          },
        });
      }
      else if (this.data.startdate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<this.data.startdate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.endtime<this.data.starttime){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if(this.data.name.length>10){
        wx.showToast({
          title: '名称最长为10个字符',
          icon: 'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if((this.data.startdate==currentDate)&&(this.data.enddate==currentDate)){
        if((this.data.starttime<currentTime)||(this.data.endtime<currentTime)){
           wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
          });
        }
        else{
          signCollection.where({
            _id:this.data._id
          }).update({
            data:{
              name:this.data.name,
              selectStartDate:this.data.startdate,
              selectEndDate:this.data.enddate,
              selectStartTime:this.data.starttime,
              selectEndTime:this.data.endtime,
              mapName:this.data.mapName,
              latitude:this.data.latitude,
              longitude:this.data.longitude,
              id:2,
              issigned:"未签到"
    
            }
          }).then(res=>{
            console.log("添加成功",res);
            wx.showToast({
              title: '修改成功',
              icon: 'success',
              duration: 1500,
              mask: true,
              success: (result)=>{
                this.setData({
                  name:"请输入名称",
                  startdate:"请选择",
                  enddate:"请选择",
                  starttime:"请选择",
                  endtime:"请选择",
                  mapName:"请选择"
                })
              
              
              },
            
            });
           
          }).catch(err=>{
            console.log("添加失败",err);
          })
    
    
        }
      } 
      else{
        signCollection.where({
          _id:this.data._id
        }).update({
          data:{
            name:this.data.name,
            selectStartDate:this.data.startdate,
            selectEndDate:this.data.enddate,
            selectStartTime:this.data.starttime,
            selectEndTime:this.data.endtime,
            mapName:this.data.mapName,
            latitude:this.data.latitude,
            longitude:this.data.longitude,
            id:2,
            issigned:"未签到"
  
          }
        }).then(res=>{
          console.log("添加成功",res);
          wx.showToast({
            title: '修改成功',
            icon: 'success',
            duration: 1500,
            mask: true,
            success: (result)=>{
              this.setData({
                name:"请输入名称",
                startdate:"请选择",
                enddate:"请选择",
                starttime:"请选择",
                endtime:"请选择",
                mapName:"请选择"
              })
            
            
            },
          
          });
         
        }).catch(err=>{
          console.log("添加失败",err);
        })
  
      }
    }

    //修改密码签到
    if(this.data.id==3){
      if (this.data.name==""||this.data.startdate=="请选择"||this.data.enddate=="请选择"||this.data.starttime=="请选择"||this.data.endtime=="请选择"||this.data.code=="点击生成") {
        wx.showToast({
          title: '信息不全',
          icon: 'error',
          duration: 1500,
          mask: true,
          success: (result)=>{
            
          },
        });
      }
      else if (this.data.startdate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<currentDate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.enddate<this.data.startdate){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if (this.data.endtime<this.data.starttime){
        wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if(this.data.name.length>10){
        wx.showToast({
          title: '名称最长为10个字符',
          icon: 'none',
          duration: 1500,
          mask: true,
        });
  
      }
      else if((this.data.startdate==currentDate)&&(this.data.enddate==currentDate)){
        if((this.data.starttime<currentTime)||(this.data.endtime<currentTime)){
           wx.showToast({
          title: '日期时间不正确',
          icon:'none',
          duration: 1500,
          mask: true,
          });
        }
        else{
          signCollection.where({
            _id:this.data._id
          }).update({
            data:{
              name:this.data.name,
              selectStartDate:this.data.startdate,
              selectEndDate:this.data.enddate,
              selectStartTime:this.data.starttime,
              selectEndTime:this.data.endtime,
              code:this.data.code,
              id:3,
              issigned:"未签到"
            }
          }).then(res=>{
            console.log("添加成功",res);
            wx.showToast({
              title: '修改成功',
              icon: 'success',
              duration: 1500,
              mask: true,
              success: (result)=>{
                this.setData({
                  name:"请输入名称",
                  startdate:"请选择",
                  enddate:"请选择",
                  starttime:"请选择",
                  endtime:"请选择",
                  code:"点击生成"
                })
              
              
              },
            
            });
           
          }).catch(err=>{
            console.log("添加失败",err);
          })
        }
      } 
      else{
        signCollection.where({
          _id:this.data._id
        }).update({
          data:{
            name:this.data.name,
            selectStartDate:this.data.startdate,
            selectEndDate:this.data.enddate,
            selectStartTime:this.data.starttime,
            selectEndTime:this.data.endtime,
            code:this.data.code,
            id:3,
            issigned:"未签到"
          }
        }).then(res=>{
          console.log("添加成功",res);
          wx.showToast({
            title: '修改成功',
            icon: 'success',
            duration: 1500,
            mask: true,
            success: (result)=>{
              this.setData({
                name:"请输入名称",
                startdate:"请选择",
                enddate:"请选择",
                starttime:"请选择",
                endtime:"请选择",
                code:"点击生成"
              })
            
            
            },
          
          });
         
        }).catch(err=>{
          console.log("添加失败",err);
        })
  
      }
    }
    
  },


  onReady: function(){
    
  },
  onShow: function(){
    
  },
  onHide: function(){

  },
  onUnload: function(){

  },
  onPullDownRefresh: function(){

  },
  onReachBottom: function(){

  },
  onShareAppMessage: function(){

  },
  onPageScroll: function(){

  },
  //item(index,pagePath,text)
  onTabItemTap:function(item){

  }
});
