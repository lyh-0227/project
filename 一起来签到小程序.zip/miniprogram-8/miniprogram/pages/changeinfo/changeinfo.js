// pages/changeinfo/changeinfo.js
Page({
  data:{
    avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0',
    nickName:"微信用户"
  },

  onChooseAvatar(e) {
    console.log(e);
    const { avatarUrl } = e.detail
    
    wx.showModal({
      title: '提示',
      content: '是否要选择此照片？',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#3CC51F',
      success: (result) => {
        if(result.confirm){
            this.setData({
            avatarUrl,
          });
          //console.log(avatarUrl);
          
        }
        else{

        }
      },
      fail: ()=>{},
      complete: ()=>{}
    });

    
  },

  handleSetUserInfo(){
    //wx.setStorageSync("userinfo", avatarUrl );
    wx.showModal({
      title: '提示',
      content: '是否确定更换头像和昵称？',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#3CC51F',
      success: (result) => {
        if(result.confirm){
          // this.setData({
          //   avatarUrl,
          //   nickName:nickName
          // });
          if (this.data.avatarUrl=='https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0' || this.data.nickName==""||this.data.nickName=="微信用户"){
            wx.showToast({
              title: '头像或昵称未修改',
              icon: 'none',
              
              duration: 1500,
              mask: true,
              
            });
          }
          else{
          wx.setStorageSync("userinfo",this.data.avatarUrl);
          wx.setStorageSync("nickName",this.data.nickName);
          wx.navigateBack({
          delta: 1
          });
        }
          
        }
        else{

        }
      },
      fail: ()=>{},
      complete: ()=>{}
    });
    
  },

  handleGetUserInput(e){
    console.log(e);
    const nickName=e.detail||"";

    wx.showModal({
      title: '提示',
      content: '确定使用本昵称？',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#3CC51F',
      success: (result) => {
        if(result.confirm){
          this.setData({
            nickName:nickName
          });
        }
        else{

        }
      },
      fail: ()=>{},
      complete: ()=>{}
    });

    
  },

  
})