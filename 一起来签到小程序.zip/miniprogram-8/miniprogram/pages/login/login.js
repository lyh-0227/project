Page({
  data:{
    // useravatarUrl:"",
    // nickName:"",
    //userinfo:""

  },
  status(){
    wx.getUserProfile({
      desc: '用于登录',
      success:(res)=>{
        var userinfo=res.userInfo
        //console.log(res)
        // this.setData({
        //   // useravatarUrl:res.userInfo.avatarUrl,
        //   // nickName:res.userInfo.nickName
        //   userinfo:res.userInfo
        // })
        wx.setStorageSync('userinfo',userinfo )
        //console.log(this.data.useravatarUrl,this.data.nickName);
        wx.navigateBack({
          delta: 1,
        })
      },
      fail:()=>{
        wx.showToast({
          title: '您需要授权才可以登录',
          icon:"none"
        })
      }

    })
    
  },
  // handleGetUserInfo(e){
  //   //console.log(e)
  //   //解构获得的信息，并将其存放到缓存中，获取成功后返回上一级
    
  //   const {userInfo}=e.detail;
  //   wx.setStorageSync("userinfo", userInfo );
  //   wx.navigateBack({
  //     delta: 1
  //   });
  // }
})
