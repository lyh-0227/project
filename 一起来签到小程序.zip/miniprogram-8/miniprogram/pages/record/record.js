//Page Object
const db = wx.cloud.database()
Page({
  data: {
    tabs:[
      {
        id:0,
        value:"普通签到",
        isActive:true
      },
      {
        id:1,
        value:"定位签到",
        isActive:false
      },
      {
        id:2,
        value:"密码签到",
        isActive:false
      }
    
    ],
    //recordid:"",
    record:[],
    signid:"",
    status:"",
    userstatus:"creator"
  },

  onShow(options){
    //获取小程序页面栈(可理解为数组)，长度最大10个页面
    let pages=getCurrentPages();
    //数组中索引最大的页面是当前页面，存在options参数，可以获取options参数
    let currentPage=pages[pages.length-1];
    //获取URL上的type参数
    const {type}=currentPage.options;
    //激活选中页面标题，index=type-1
    this.changeTitleByIndex(type-1);
    //console.log(options)
    
  },


  changeTitleByIndex(index){

    //修改原数组，定义tabs保存数据，用forEach遍历，如果某一标题被点击，则isActive属性被激活，否则不激活
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    
    //赋值到data中
    this.setData({
      tabs
    })
    //console.log(index);
    
    //tab下方页面内容随标题切换而切换
    const signCollection = db.collection('signrecord')
    signCollection
      .where({
        id:index+1
      })
      .get()
      .then(res=>{
        this.setData({
          record:res.data
        })
      })
      .catch(err=>{
        console.log(err)
      })
  
  },
  
  handleTabsItemChange(e){
    
    //获取被点击的标题索引
    const {index}=e.detail;
    this.changeTitleByIndex(index);
    
  
  },

  handleRadioChange(e){
    var userstatus=e.detail.value
    this.setData({
      userstatus:userstatus
    })
    //console.log(this.data.userstatus)
  },

  onLoad(options){
    //console.log(options);
    var id=options.id;
    id=parseInt(id)
    //console.log(typeof(id));
    const signCollection = db.collection('signrecord')
    signCollection
      .where({
        id:id
      })
      .get()
      .then(res=>{
        //console.log(res);
        
        this.setData({
          record:res.data
        })
        //console.log(this.data.record);

      })
      .catch(err=>{
        console.log(err)
      })

  },

  sign(e){
   var signid=e.currentTarget.dataset.id
   //console.log(signid)
   this.setData({
    signid:signid
   })
   wx.navigateTo({
    url: '/pages/signdetail/signdetail?id='+this.data.signid,
    success: (result)=>{
      
    },
    fail: ()=>{},
    complete: ()=>{}
   });
   
  },

  change(e){
    var signid=e.currentTarget.dataset.id;
    this.setData({
      signid:signid
    })
    //console.log(this.data.signid)
    wx.navigateTo({
      url: '/pages/changesigndetail/changesigndetail?id='+this.data.signid,
      success: (result)=>{
        
      },
      fail: ()=>{},
      complete: ()=>{}
    });
  },


  delete(e){
    var signid=e.currentTarget.dataset.id
    wx.showModal({
      title: '提示',
      content: '您确定要删除该记录吗？',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#3CC51F',
      success: (result) => {
        if(result.confirm){
          
          const signCollection = db.collection('signrecord')
          signCollection.where({
            _id:signid
          }).remove()
          .then(res=>{
            wx.showToast({
              title: '删除成功',
              icon: 'none',
              duration: 1500,
              mask: true,

            });
          })
          .catch(err=>{
            console.log("删除失败")
          })
        }
        else{

        }
      },
      fail: ()=>{},
      complete: ()=>{}
    });
  },

  refresh(){
    wx.reLaunch({
      url: '/pages/user/user',
      success: (result)=>{
        
      },
      fail: ()=>{},
      complete: ()=>{}
    });
  }

});