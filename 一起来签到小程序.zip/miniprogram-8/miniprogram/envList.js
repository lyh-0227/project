const envList = [{"envId":"cloud1-4gwi4bf4ca245709","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}