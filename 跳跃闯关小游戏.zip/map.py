import pygame
#引入处理Python环境运行的模块
import sys
#引入pickle库，进行序列化和反序列化，实现游戏进度保存，引入路径
import pickle
from os import path

pygame.init()
#每秒帧数为60
time=pygame.time.Clock()
fps=60
#游戏窗口的高度和宽度(以格子为单位，每一列为30，共20列)
grid_size=30
column_width=20
#预留放按钮的区域
margin=100
screen_width=grid_size*column_width
screen_height=grid_size*20+margin
#窗口显示，放入的内容为元组（窗口宽度和高度），标题为“游戏地图编辑器”
screen=pygame.display.set_mode((screen_width,screen_height))
pygame.display.set_caption("游戏地图编辑器")

#关于颜色的和字体定义
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
grey = (141, 116, 109)
style=pygame.font.SysFont("SimSun",20)

#图片的加载与转换，转换为符合格子大小的图片
background=pygame.image.load("img/sky2.jpg")
background=pygame.transform.scale(background,(screen_width,screen_height-margin))
grass=pygame.image.load("img/grass.jpg")
grass=pygame.transform.scale(grass,(grid_size,grid_size))
dirt=pygame.image.load("img/dirt.jpg")
dirt=pygame.transform.scale(dirt,(grid_size,grid_size))
x_platform=pygame.image.load("img/x_platform.jpg")
x_platform=pygame.transform.scale(x_platform,(grid_size,int(grid_size*0.5)))
y_platform=pygame.image.load("img/y_platform.jpg")
y_platform=pygame.transform.scale(y_platform,(grid_size,int(grid_size*0.5)))
enemy=pygame.image.load("img/enemy.jpg")
enemy=pygame.transform.scale(enemy,(grid_size,int(grid_size*0.7)))
lava=pygame.image.load("img/lava2.png")
lava=pygame.transform.scale(lava,(grid_size,int(grid_size*0.5)))
diamond=pygame.image.load("img/diamond2.png")
diamond=pygame.transform.scale(diamond,(int(grid_size*0.5),int(grid_size*0.5)))
exit=pygame.image.load("img/exit2.png")
exit=pygame.transform.scale(exit,(grid_size,int(grid_size*1.5)))
save=pygame.image.load("img/save2.jpg")
load=pygame.image.load("img/load.jpg")

#创建空的列表，用来记录屏幕中每一格的内容
map=[]
for i in range(20):#每行有20个0，每次增加一行，增加20次，生成一个行和列均为20的列表
    row=[0]*20
    map.append(row)

#创建边界，grid遍历列
for grid in range(0,20):
    map[19][grid]=1 #底边为草地


#在窗口中显示格子，更利于设置地图(横竖各画19条)
def grid_drawing():
    for i in range(20):
        pygame.draw.line(screen,black,(i*grid_size,0),(i*grid_size,screen_height-margin)) #在屏幕上画竖线
        pygame.draw.line(screen,black,(0,i*grid_size),(screen_width,i*grid_size)) #在屏幕上画横线

#将地图列表进行数据渲染，二重循环依次遍历行和列并对该行列内容进行判断，1-8代表不同的图像
#1:草地，2：泥土，3：左右移动的平台，4：上下移动的平台，5：敌人，6：岩浆，7：钻石，8：出口
def map_drawing():
    for i in range(20):
        for j in range(20):
            if map[i][j]>0:
                if map[i][j]==1:
                    screen.blit(grass,(j*grid_size,i*grid_size))
                if map[i][j]==2:
                    screen.blit(dirt,(j*grid_size,i*grid_size))
                if map[i][j]==3:
                    screen.blit(x_platform,(j*grid_size,i*grid_size))
                if map[i][j]==4:
                    screen.blit(y_platform,(j*grid_size,i*grid_size))
                if map[i][j]==5:
                    screen.blit(enemy,(j*grid_size,i*grid_size+grid_size*0.3))
                if map[i][j]==6:
                    screen.blit(lava,(j*grid_size,i*grid_size+int((grid_size*0.5))))
                if map[i][j]==7:
                    screen.blit(diamond,(j*grid_size+int(grid_size*0.25),i*grid_size+int(grid_size*0.25)))
                if map[i][j]==8:
                    screen.blit(exit,(j*grid_size,i*grid_size-int(grid_size*0.5)))

#定义一个按钮可以使用的类
class ButtonEvents():
    #初始化方法，包含按钮的x，y坐标和图片
    def __init__(self,x,y,img):
        self.image=img                   #图片就是插入的图片
        self.reaction=self.image.get_rect()  #事件为图片本身的事件
        self.reaction.x=x
        self.reaction.y=y                    #按钮(x,y)坐标
        self.isclicked=False             #按钮被点击初始状态为False

    #绘制按钮函数
    def button_drawing(self):
        buttonIsclicked=False                    #按钮被点击参数，初始状态为False
        position=pygame.mouse.get_pos()          #获取鼠标位置
        if self.reaction.collidepoint(position): #判断点击位置是否在按钮位置之内，collidepoint函数检测按钮所在位置是否与鼠标指针发生碰撞
            if pygame.mouse.get_pressed()[0]==1 and self.isclicked==False:   #如果鼠标左键点击了按钮所在区域
                buttonIsclicked=True
                self.isclicked=False             #则将反映按钮点击的状态变为True，将自身的按钮点击变量变为False供下次点击使用
        if pygame.mouse.get_pressed()[0]==0:     #如果没有点击则将鼠标点击状态变量变为false
            self.isclicked=False
        screen.blit(self.image,(self.reaction.x,self.reaction.y))  #将图片显示到屏幕上
        return buttonIsclicked                                     #将鼠标点击的状态返回

#显示文本的函数
def text(text,style,color,x,y):
    image=style.render(text,True,color)  #将文字转换为图片
    screen.blit(image,(x,y))

#使用ButtonEvents类生成save和load两个按钮变量
save=ButtonEvents(int(screen_width*0.5)-90,screen_height-80,save)
load=ButtonEvents(int(screen_width*0.5)+50,screen_height-80,load)

#定义鼠标点击事件和关卡初始难度
MouseClick=False
passlevel=1

#循环显示游戏窗口
display=True
while display:

    #定义帧率和制作背景
    time.tick(fps)
    screen.fill(grey)
    #制作背景为屏幕全覆盖
    screen.blit(background,(0,0))
    #screen.blit(sun,(60,60))
    #画格子以及加载地图数据
    grid_drawing()
    map_drawing()

    #显示按钮以及完成按钮功能
    if save.button_drawing():
        pickleDataout=open(f"passlevel{passlevel}.data","wb")   #若保存按钮被点击则保存数据,使用序列化和反序列化编译成二进制文件，使用二进制读写方法
        pickle.dump(map,pickleDataout)                          #调用dump函数序列化，序列化内容为map，路径为pickleData
        pickleDataout.close()
    if load.button_drawing():
        if path.exists(f"passlevel{passlevel}.data"):           #若加载按钮被点击则加载对应级别数据,若数据存在则用二进制读取文件方式加载
            pickleDatain=open(f"passlevel{passlevel}.data","rb") #读取文件内容
            map=pickle.load(pickleDatain)                        #调用load函数反序列化以显示数据

    #显示当前级别
    text(f'关卡: {passlevel}', style, white, grid_size+20, screen_height - 70)

    #循环遍历事件，根据事件类型进行相应响应
    for event in pygame.event.get():

        #若退出，则变量display变成false后窗口退出关闭
        if event.type==pygame.QUIT:
            display=False
            pygame.quit()
            sys.exit()

        #鼠标按下事件
        if event.type==pygame.MOUSEBUTTONDOWN and MouseClick==False: #鼠标按下且按一次
            MouseClick=True
            position=pygame.mouse.get_pos()   #获取鼠标点击的位置
            x=position[0]//grid_size
            y=position[1]//grid_size          #计算出点击的格子的位置(位于第x行第y列)
            if x<20 and y<20:
                if pygame.mouse.get_pressed()[0]==1: #如果鼠标左键按下（get_pressed()函数监听鼠标按下事件，0表示左键，1表示中键，2表示右键）
                    map[y][x]=map[y][x]+1            #更新当前格子的图片内容
                    if map[y][x]>=9:
                        map[y][x]=0                  #如果所有图片都更换了一遍，再点击时则变为空

        #鼠标抬起事件
        if event.type==pygame.MOUSEBUTTONUP:
            MouseClick=False


        #通过键盘上下键或者“+”和“-”键控制关卡级别选择
        if event.type == pygame.KEYDOWN:
            if (event.key == pygame.K_EQUALS) or (event.key==pygame.K_UP):
                passlevel=passlevel+1
            elif (event.key == pygame.K_MINUS) or (event.key==pygame.K_DOWN):
                if passlevel>1:
                    passlevel=passlevel-1

    #循环显示窗口和帧
    pygame.display.update()

