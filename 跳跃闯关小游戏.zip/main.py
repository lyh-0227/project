import pygame
#引入处理Python环境运行的模块
import sys
import os
import pickle
from pygame.locals import *
from pygame import mixer

pygame.init()
pygame.mixer.pre_init(44100,-16,2,512)            #声音库初始化，默认参数44100
mixer.init()
#定义游戏变量
gridSize=40
isgameover=0
mainMenu=True
passlevel=1
maxPasslevel=4
number=0
score=0
delay=0

#定义游戏窗口的宽度和高度
scWidth=800
scHeight=800
#每秒帧数为60
time=pygame.time.Clock()
fps=60
#关于颜色和字体定义
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
blue = (0, 42, 255)
grey = (141, 116, 109)
style=pygame.font.SysFont("TimesNew Roman",20)
character=pygame.font.SysFont("TimesNew Roman",40)
Chinese=pygame.font.SysFont("SimSun",20)

#设置屏幕尺寸和标题
screen=pygame.display.set_mode((scWidth,scHeight))#函数中第一个变量为元组类型的屏幕尺寸
pygame.display.set_caption("闯关游戏")


#创建地图类
class gameMap(object):
    #初始化函数
    def __init__(self,data):
        self.gridList=[]                             #定义一个列表，用来保存每一个图片和位置信息
        dirt=pygame.image.load("img/dirt.jpg")
        dirt=pygame.transform.scale(dirt,(gridSize,gridSize))
        grass=pygame.image.load("img/grass.jpg")      #加载泥土和草地图片
        grass=pygame.transform.scale(grass,(gridSize,gridSize))
        rowCount=0                                      #统计行数
        for row in data:
            columnCount=0                                  #统计列数
            for grid in row:
                if grid==1:                               #如果为1则为泥土，通过循环遍历行和列之后就可以把每一个1的位置显示上泥土图片
                    grassRect=grass.get_rect()         #将图片显示
                    grassRect.x=columnCount*gridSize        #图片的x坐标为当前1的位置所在的列数×每个格子的宽度
                    grassRect.y=rowCount*gridSize        #图片的y坐标为当前1的位置所在的行数×每个格子的宽度
                    rect=(grass,grassRect)              #将图像和坐标信息用元组类型的变量rect保存
                    self.gridList.append(rect)
                if grid==2:                               #如果为2则为草地，通过循环遍历行和列之后就可以把每一个2的位置显示上草地图片
                    dirtRect=dirt.get_rect()           # 将图片显示
                    dirtRect.x=columnCount*gridSize         # 图片的x坐标为当前2的位置所在的列数×每个格子的宽度
                    dirtRect.y=rowCount*gridSize         # 图片的y坐标为当前2的位置所在的行数×每个格子的宽度
                    rect=(dirt,dirtRect)               # 将图像和坐标信息用元组类型的变量rect保存
                    self.gridList.append(rect)
                if grid==3:                                                            #如果为3则为x方向的移动的平台
                    platform=gamePlatform(columnCount*gridSize,rowCount*gridSize,1,0)  #用变量将类实例化，（1,0）表示沿x轴移动
                    platformGroup.add(platform)                                        #将实例化后的变量加入到组中
                if grid==4:                                                            #如果为4则为y方向的移动的平台
                    platform=gamePlatform(columnCount*gridSize,rowCount*gridSize,0,1)  #用变量将类实例化，（0,1）表示沿y轴移动
                    platformGroup.add(platform)                                        #将实例化后的变量加入到组中
                if grid==5:                               #如果为5则为敌人，通过循环遍历行和列之后就可以把每一个5的位置显示上敌人图片
                    enemy=gameEnemy(columnCount*gridSize,rowCount*gridSize+5)     #用变量将类实例化
                    enemyGroup.add(enemy)                                  #将实例化之后的变量加入到组中
                if grid==6:                               #如果为6则为岩浆，通过循环遍历行和列之后就可以把每一个6的位置显示上岩浆图片
                    lava=gameLava(columnCount*gridSize,rowCount*gridSize+5)     #用变量将类实例化
                    lavaGroup.add(lava)                                  #将实例化之后的变量加入到组中
                if grid==7:
                    diamond=gameDiamond(columnCount*gridSize+int(gridSize*0.5),rowCount*gridSize+5)
                    diamondGroup.add(diamond)
                if grid==8:                              #如果为8则为出口，通过循环遍历行和列之后就可以把每一个8的位置显示上出口图片
                    exit=gameExit(columnCount*gridSize,rowCount*gridSize)       #用变量将类实例化
                    exitGroup.add(exit)                                  #将实例化之后的变量加入到组中
                columnCount=columnCount+1
            rowCount=rowCount+1
    #将初始化的内容显示到屏幕上
    def display(self):
        for grid in self.gridList:                      #依次遍历列表，列表中每个元素包含两个属性值，第一个为图片，第二个为其坐标（x，y）
            screen.blit(grid[0],grid[1])                #在屏幕上显示，grid[0]为图像内容，grid[1]为图像x，y坐标


#创建玩家类
class gamePlayer():

    #初始化函数
    def __init__(self,x,y):
        self.imageRight=[]                                  #向右走时的动画列表
        self.imageLeft=[]                                   #向左走时的动画列表
        self.index=0                                        #播放走路动画的索引下标值
        self.number=0                                       #播放次数
        self.direction=0                                    #走路方向

        for i in range(1,5):                                #使用循环播放四张图片以实现走路效果
            imageRight=pygame.image.load(f"img/man{i}.png")              #向右走
            imageRight=pygame.transform.scale(imageRight,(40,80))
            imageLeft=pygame.transform.flip(imageRight,True,False)       #利用flip（）函数进行方向转换
            self.imageRight.append(imageRight)
            self.imageLeft.append(imageLeft)

        self.dead=pygame.image.load("img/ghost2.png")
        self.image=self.imageRight[self.index]              #因为image内容已改变，所以重新从imageRight列表中找到第一个向右的图片进行赋值
        self.rect=self.image.get_rect()
        self.rect.x=x
        self.rect.y=y                                    #x，y坐标
        self.verticalJump=0                              #垂直方向上弹跳的距离
        self.jump=False                                  #判断是否起跳的变量
        self.air=True                                    #判断是否在空中
        self.playerWidth = self.image.get_width()
        self.playerHeight = self.image.get_height()          #获取玩家的宽度和高度


    #玩家移动属性
    def update(self,isgameover):
        horizon=0                                                                  #左右移动的距离
        vertical=0                                                                 #向上移动的距离
        walkInterval=5                                                             #走路的间隔时间
        coldTime=20                                                                #冷却时间

        if isgameover==0:                                                          #游戏正常进行时
            keyboardKey=pygame.key.get_pressed()                                    #监听键盘按键
            if keyboardKey[pygame.K_LSHIFT]==True or keyboardKey[pygame.K_RSHIFT]:

                if (keyboardKey[pygame.K_UP] and self.jump==False and self.air==False) or \
                        (keyboardKey[pygame.K_w] and self.jump==False and self.air==False):        #如果玩家没有跳起来且按了上键
                    jumpMusic.play()
                    self.verticalJump=-20
                    self.jump=True                                  #如果按下上键或者w键，在没有起跳的情况下可以跳跃
                if keyboardKey[pygame.K_UP]==False:                                        #如果没有按下上键
                    self.jump=False
                if keyboardKey[pygame.K_w]==False:                                         #如果没有按下w键
                    self.jump=False
                if keyboardKey[pygame.K_LEFT] or keyboardKey[pygame.K_a]:                  #如果键盘左键按下则向左移动1像素
                    horizon=horizon-5
                    self.number=self.number+1                                              #播放的次数+1
                    self.direction=-1                                                      #调整玩家走路的方向为左，-1表示左
                if keyboardKey[pygame.K_RIGHT] or keyboardKey[pygame.K_d]:                 #如果键盘右键按下则向右移动1像素
                    horizon=horizon+5
                    self.number=self.number+1
                    self.direction=1                                                       #调整玩家走路的方向为右，1表示右
                for platform in platformGroup:  # 玩家与移动平台的碰撞
                    if platform.rect.colliderect(self.rect.x + horizon, self.rect.y, self.playerWidth,
                                                 self.playerHeight):  # x方向上的碰撞
                        horizon = 0
                    if platform.rect.colliderect(self.rect.x, self.rect.y + vertical, self.playerWidth,
                                                 self.playerHeight):  # y方向上的碰撞
                        if abs(self.rect.top + vertical - platform.rect.bottom) < coldTime:  # y方向底部的碰撞
                            self.verticalJump = 0
                            vertical = platform.rect.bottom - self.rect.top
                        elif abs(self.rect.bottom + vertical - platform.rect.top) < coldTime:  # y方向顶部的碰撞
                            self.rect.bottom = platform.rect.top - 1
                            self.air = False
                            vertical = 0
                        if platform.xmove == 1:
                            self.rect.x = self.rect.x + platform.direction

            elif keyboardKey[pygame.K_LSHIFT]==False and keyboardKey[pygame.K_RSHIFT]==False:

                if (keyboardKey[pygame.K_UP] and self.jump==False and self.air==False) or \
                        (keyboardKey[pygame.K_w] and self.jump==False and self.air==False):  # 如果玩家没有跳起来且按了上键
                    jumpMusic.play()
                    self.verticalJump=-10
                    self.jump=True                                 # 如果按下上键或者w键，在没有起跳的情况下可以跳跃
                if keyboardKey[pygame.K_UP]==False:                                       # 如果没有按下上键
                    self.jump=False
                if keyboardKey[pygame.K_w]==False:                                        # 如果没有按下w键
                    self.jump=False
                if keyboardKey[pygame.K_LEFT] or keyboardKey[pygame.K_a]:                   # 如果键盘左键按下则向左移动1像素
                    horizon=horizon-1
                    self.number=self.number+1                                           # 播放的次数+1
                    self.direction=-1                                                     # 调整玩家走路的方向为左，-1表示左
                if keyboardKey[pygame.K_RIGHT] or keyboardKey[pygame.K_d]:                  # 如果键盘右键按下则向右移动1像素
                    horizon=horizon+1
                    self.number=self.number+1
                    self.direction=1                                                      # 调整玩家走路的方向为右，1表示右
                for platform in platformGroup:  # 玩家与移动平台的碰撞
                    if platform.rect.colliderect(self.rect.x + horizon, self.rect.y, self.playerWidth,
                                                 self.playerHeight):  # x方向上的碰撞
                        horizon = 0
                    if platform.rect.colliderect(self.rect.x, self.rect.y + vertical, self.playerWidth,
                                                 self.playerHeight):  # y方向上的碰撞
                        if abs(self.rect.top + vertical - platform.rect.bottom) < coldTime:  # y方向底部的碰撞
                            self.verticalJump = 0
                            vertical = platform.rect.bottom - self.rect.top
                        elif abs(self.rect.bottom + vertical - platform.rect.top) < coldTime:  # y方向顶部的碰撞
                            self.rect.bottom = platform.rect.top - 1
                            self.air = False
                            vertical = 0
                        if platform.xmove == 1:
                            self.rect.x = self.rect.x + platform.direction

            if keyboardKey[pygame.K_LEFT]==False and keyboardKey[pygame.K_a]==False and \
                    keyboardKey[pygame.K_RIGHT]==False and keyboardKey[pygame.K_d]==False:
                self.number=0
                self.index=0                                                        #如果a键、d键、左键和右键没有被按下时则不播放任何动画
                if self.direction==1:
                    self.image=self.imageRight[self.index]                          #如果此时方向向右，则加载向右的图像
                if self.direction==-1:
                    self.image=self.imageLeft[self.index]                           #如果此时方向向左，则加载向左的图像

            if self.number>walkInterval:                                            #实现走路时动画播放
                self.number=0
                self.index=self.index+1
                if self.index>=len(self.imageRight):
                    self.index=0                                                     #当超出图片数组索引值时从第一张图片开始
                if self.direction==1:
                    self.image=self.imageRight[self.index]                           #若向右，则从imageRight列表中进行加载
                if self.direction==-1:
                    self.image=self.imageLeft[self.index]                            #若向左，则从imageLeft列表中进行加载

            self.verticalJump+=1
            if self.verticalJump>5:                           #按下跳跃键后往上走，到达最高点后变化的量逐渐加1而达到下落的效果
                self.verticalJump=5
            vertical+=self.verticalJump                        #将变化量加到位置上

            self.air=True
            for grid in gamemap.gridList:                      #检测玩家与每个草地、泥土的碰撞
                if grid[1].colliderect(self.rect.x+horizon,self.rect.y,self.playerWidth,self.playerHeight):
                    horizon=0                                  #检测x方向上的碰撞，横向有原坐标＋走动的量
                if grid[1].colliderect(self.rect.x,self.rect.y+vertical,self.playerWidth,self.playerHeight):
                                                               #检测y方向上的碰撞，纵向有原坐标＋走动的量
                    if self.verticalJump<0:                    #检测玩家顶部与泥块底部碰撞
                        vertical=grid[1].bottom-self.rect.top
                        self.verticalJump=0
                    elif self.verticalJump>=0:                 #检测玩家底部与泥块顶部的碰撞
                        vertical=grid[1].top-self.rect.bottom
                        self.verticalJump=0
                        self.air=False

            if pygame.sprite.spritecollide(self,lavaGroup,False):        #检测玩家和岩浆的碰撞
                gameoverMusic.play()
                isgameover=-1

            if pygame.sprite.spritecollide(self,exitGroup,False):        #检测玩家和出口的碰撞
                isgameover=1                                             #玩家获胜

            for platform in platformGroup:                               #玩家与移动平台的碰撞
                if platform.rect.colliderect(self.rect.x+horizon,self.rect.y,self.playerWidth,self.playerHeight):#x方向上的碰撞
                    horizon=0
                if platform.rect.colliderect(self.rect.x,self.rect.y+vertical,self.playerWidth,self.playerHeight):#y方向上的碰撞
                    if abs(self.rect.top+vertical-platform.rect.bottom)<coldTime:           #y方向底部的碰撞
                        self.verticalJump=0
                        vertical=platform.rect.bottom-self.rect.top
                    elif abs(self.rect.bottom+vertical-platform.rect.top)<coldTime:         #y方向顶部的碰撞
                        self.rect.bottom=platform.rect.top-1
                        self.air=False
                        vertical=0
                    if platform.xmove==1:
                        self.rect.x=self.rect.x+platform.direction


            self.rect.x+=horizon
            self.rect.y+=vertical                        #根据玩家位置的变化更新玩家位置

            if self.rect.bottom > scHeight:
                self.rect.bottom = scHeight              #玩家超出最底部边界设置
                vertical = 0
        elif isgameover==-1:
            self.image=self.dead
            displayDrawing("游戏结束!",pygame.font.SysFont("SimSun",40),red,int(scWidth*0.5)-80,int(scHeight*0.5))
        screen.blit(self.image,self.rect)            #将玩家显示在屏幕上

        return isgameover

#关于敌人的类，继承Sprite类
class gameEnemy(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()                                 #父类的初始化方法
        self.image=pygame.image.load("img/enemy.jpg")      #加载图片
        self.rect=self.image.get_rect()                    #sprite.py文件中sprite类中的draw（）函数里精灵的自带属性为rect，不可更改，否则报错
        self.rect.x=x
        self.rect.y=y                                      #获取图片当前的坐标（x，y）
        self.direction=1                                   #设置默认移动方向，1为正向
        self.number=0                                      #设置移动次数

    def update(self):
        self.rect.x=self.rect.x+self.direction              #x方向上的移动
        self.number=self.number+1                           #统计移动次数
        if abs(self.number)>50:                             #如果移动次数大于50次则反向
            self.direction=self.direction*(-1)
            self.number=self.number*(-1)

#关于岩浆类，继承Sprite类
class gameLava(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()                                 #父类的初始化方法
        image=pygame.image.load("img/lava2.png")            #加载图片
        self.image=pygame.transform.scale(image,(gridSize,gridSize))
        self.rect=self.image.get_rect()                    #sprite.py文件中sprite类中的draw（）函数里精灵的自带属性为rect，不可更改，否则报错
        self.rect.x=x
        self.rect.y=y                                      #获取图片当前的坐标（x，y）

#创建钻石
class gameDiamond(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()                                 #父类的初始化方法
        image=pygame.image.load("img/diamond2.png")            #加载图片
        self.image=pygame.transform.scale(image,(int(gridSize*0.5),int(gridSize*0.5)))
        self.rect=self.image.get_rect()                    #sprite.py文件中sprite类中的draw（）函数里精灵的自带属性为rect，不可更改，否则报错
        self.rect.center=(x,y)                             #获取其中心坐标


#关于出口类，继承Sprite类
class gameExit(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()                                 #父类初始化方法
        image=pygame.image.load("img/exit2.png")           #加载图片
        self.image=pygame.transform.scale(image,(gridSize,gridSize))
        self.rect=self.image.get_rect()                    #sprite.py文件中sprite类中的draw（）函数里精灵的自带属性为rect，不可更改，否则报错
        self.rect.x=x
        self.rect.y=y                                      #获取图片当前的坐标（x，y）

#创建平台
class gamePlatform(pygame.sprite.Sprite):
    def __init__(self,x,y,xmove,ymove):
        super().__init__()                                 #父类的初始化方法
        image=pygame.image.load("img/platform.jpg")        #加载图片
        self.image=pygame.transform.scale(image,(gridSize,int(gridSize*0.5)))
        self.rect=self.image.get_rect()                    #sprite.py文件中sprite类中的draw（）函数里精灵的自带属性为rect，不可更改，否则报错
        self.rect.x=x
        self.rect.y=y                                      #获取图片当前的坐标（x，y）
        self.direction=1                                   #设置默认移动方向，1为正向
        self.number=0                                      #设置移动次数
        self.xmove=xmove                                   #设置沿x轴移动的变量
        self.ymove=ymove                                   #设置沿y轴移动的变量

    def update(self):
        self.rect.x=self.rect.x+self.direction*self.xmove               #x方向上的移动
        self.rect.y=self.rect.y+self.direction*self.ymove               #y方向上的移动
        self.number=self.number+1                                       #统计移动次数
        if abs(self.number)>50:                                         #如果移动次数大于50次则反向
            self.direction=self.direction*(-1)
            self.number=self.number*(-1)


#创建按钮
class gameButton():
    def __init__(self,x,y,image):                               #按钮类的初始化函数，传递按钮的（x，y）坐标和图像
        self.image=image                                        #按钮图像
        self.buttonRect=self.image.get_rect()
        self.buttonRect.x=x
        self.buttonRect.y=y                                     #按钮的x，y坐标
        self.isclick=False                                      #按钮是否被点击变量

    def display(self):
        isaction=False                                          #按钮是否被激活变量
        position=pygame.mouse.get_pos()                         #得到鼠标点击的位置
        if self.buttonRect.collidepoint(position):              #检测鼠标指针和按钮位置的碰撞
            if pygame.mouse.get_pressed()[0]==1 and self.isclick==False:    #如果鼠标左键点击了则参数均变为True
                isaction=True
                self.isclick=True
        if pygame.mouse.get_pressed()[0]==0:                                #没有点击则变为False
            self.isclick=False
        screen.blit(self.image,self.buttonRect)
        return isaction

#重置关卡
def resetPasslevel(passlevel):
    gameplayer.__init__(100,scHeight-130)                       #玩家、敌人、岩浆、出口均初始化重置
    enemyGroup.empty()
    lavaGroup.empty()
    exitGroup.empty()
    diamondGroup.empty()

    if os.path.exists(f"./passlevel{passlevel}.data"):          #检测路径是否存在
        pickleIn = open(f"passlevel{passlevel}.data", "rb")     #存在并读取路径文件
        map = pickle.load(pickleIn)
    gamemap = gameMap(map)                                      #加载地图
    return  gamemap

#显示文本信息
def displayDrawing(text,font,color,x,y):
    image=font.render(text,True,color)
    screen.blit(image,(x,y))

#加载图片和声音素材

background=pygame.image.load("img/sky2.jpg")
title=pygame.image.load("img/title.png")
congratulations=pygame.image.load("img/congratulations.png")
restart=pygame.image.load("img/restart.jpg")
start=pygame.image.load("img/start.jpg")
exit=pygame.image.load("img/exit2.jpg")
pygame.mixer.music.load("music/backgroundmusic.mp3")
pygame.mixer.music.play(-1,0.0,3000)
pygame.mixer.music.set_volume(0.2)
diamondMusic=pygame.mixer.Sound("music/diamond.mp3")
diamondMusic.set_volume(0.6)
jumpMusic=pygame.mixer.Sound("music/jump.mp3")
jumpMusic.set_volume(0.6)
gameoverMusic=pygame.mixer.Sound("music/gameover.wav")
gameoverMusic.set_volume(0.6)
winMusic=pygame.mixer.Sound("music/win.mp3")
winMusic.set_volume(0.5)

#使用上面的类，创建实例对象
enemyGroup=pygame.sprite.Group()                   #创建组，将类实例化之后加到组里才可以进行显示，注意这行代码的位置一定要在地图的上方，否则报错
lavaGroup=pygame.sprite.Group()
diamondGroup=pygame.sprite.Group()
exitGroup=pygame.sprite.Group()
platformGroup=pygame.sprite.Group()
gameplayer=gamePlayer(100,scHeight-130)
startButton=gameButton(int(scWidth*0.5-350),int(scHeight*0.5)-50,start)
exitButton=gameButton(int(scWidth*0.5+150),int(scHeight*0.5)-50,exit)
restartButton=gameButton(int(scWidth*0.5-50),int(scHeight*0.5+100),restart)

#左上角的钻石
virtualDiamond=gameDiamond(int(gridSize*0.5),int(gridSize*0.5))
diamondGroup.add(virtualDiamond)

#引入地图数据
if os.path.exists(f"./passlevel{passlevel}.data"):    #检测路径是否存在
    pickleIn=open(f"passlevel{passlevel}.data","rb")  #存在并读取路径文件
    map=pickle.load(pickleIn)
gamemap=gameMap(map)                                  #加载地图


#循环显示游戏窗口
display=True
while display:

    #定义帧率和制作背景
    time.tick(fps)
    #绘制背景
    screen.blit(background,(0,0))

    if mainMenu==True:

        screen.blit(title,(int(scWidth*0.5)-120,int(scHeight*0.5)-240))
        displayDrawing("按住h键获取游戏帮助",Chinese, red,scWidth-200,gridSize)
        if exitButton.display():
            display=False
        if startButton.display():
            mainMenu=False
        if pygame.key.get_pressed()[pygame.K_h]:
            displayDrawing("基础操作：↑键/w键跳跃；←键/a键向左移动；→键/d键向右移动",Chinese,red,gridSize+60,int(scHeight*0.5)+130)
            displayDrawing("shift键+基础键位操作可实现加速行走以及高跳效果",Chinese,red,gridSize+130,int(scHeight*0.5)+160)
            displayDrawing("这一路上你会遇见钻石，拾取钻石会获得相应分数", Chinese, red, gridSize+130, int(scHeight * 0.5) + 190)
            displayDrawing("你也会遇到敌人和岩浆，这会让你分数清零并死亡", Chinese, red, gridSize+130, int(scHeight * 0.5) + 220)
            displayDrawing("遇到它们也不要怕，按下↓键或者s键即可避免死亡还会获得额外分数", Chinese, red, gridSize+60, int(scHeight * 0.5) + 250)
            displayDrawing("预祝一切顺利，加油！", Chinese, red, gridSize+240, int(scHeight * 0.5) + 280)

    elif mainMenu==False:
        #显示地图
        gamemap.display()
        #显示玩家
        isgameover=gameplayer.update(isgameover)
        #显示并更新敌人
        if isgameover==0:
            enemyGroup.update()
            platformGroup.update()
            if pygame.sprite.spritecollide(gameplayer, diamondGroup, True):
                number=number+1
                score=score+1
                diamondMusic.play()

            if pygame.sprite.spritecollide(gameplayer, enemyGroup, False):  # 检测玩家和敌人的碰撞
                if pygame.key.get_pressed()[pygame.K_DOWN] or pygame.key.get_pressed()[pygame.K_s]:  # 如果在碰撞时下键或s键按下则得分加倍，游戏继续
                    isgameover = 0
                    score=score+10

                elif pygame.key.get_pressed()[pygame.K_DOWN] == False and pygame.key.get_pressed()[pygame.K_s] == False:  # 否则玩家死亡，游戏结束
                    isgameover = -1
                    gameoverMusic.play()
            displayDrawing("X" + str(number)+" "+"分数:"+str(score), Chinese, red, gridSize - 10, 10)
            if pygame.key.get_pressed()[pygame.K_ESCAPE]:
                display = False
                pygame.quit()
                sys.exit()

        enemyGroup.draw(screen)
        #显示岩浆
        lavaGroup.draw(screen)
        #显示钻石
        diamondGroup.draw(screen)
        #显示出口
        exitGroup.draw(screen)
        #显示可移动的平台
        platformGroup.draw(screen)

        if passlevel<=maxPasslevel:
            displayDrawing(f"关卡 {passlevel}",Chinese,red,scWidth-100,10)

        #判断玩家是否死亡，死亡则显示restart按钮
        if isgameover==-1:
            if restartButton.display()==True:            #如果按钮正常显示（即玩家死亡）
                gameplayer.__init__(100,scHeight-130)   #进行初始化，并将玩家游戏状态值进行更改
                isgameover=0
                number=0
                score=0
                diamondGroup.update()
                # 左上角的钻石
            virtualDiamond = gameDiamond(int(gridSize * 0.5), int(gridSize * 0.5))
            diamondGroup.add(virtualDiamond)
            displayDrawing("X" + str(number) + " " + "分数:" + str(score), Chinese, red, gridSize - 10, 10)
            if pygame.key.get_pressed()[pygame.K_ESCAPE]:
                display = False
                pygame.quit()
                sys.exit()


        #判断玩家本关是否通过，通过则加载下一关
        if isgameover==1:
            passlevel=passlevel+1
            if passlevel<=maxPasslevel:
                map=[]
                gamemap=resetPasslevel(passlevel)
                isgameover=0
            else:
                screen.blit(background,(0,0))
                screen.blit(congratulations,(int(scWidth*0.5)-170,int(scHeight*0.5)+130))
                virtualDiamond = gameDiamond(int(gridSize * 0.5), int(gridSize * 0.5))
                diamondGroup.add(virtualDiamond)
                displayDrawing("X" + str(number) + " " + "分数:" + str(score), Chinese, red, gridSize - 10, 10)
                displayDrawing(f"你得到了{number}个钻石和{score}分",pygame.font.SysFont("SimSun",40),red,int(scWidth*0.5)-170,int(scHeight*0.5)-50)
                displayDrawing("恭喜你全部通关！",pygame.font.SysFont("SimSun",40),red,int(scWidth*0.5)-140,int(scHeight*0.5))
                winMusic.play()
            # 左上角的钻石
            virtualDiamond = gameDiamond(int(gridSize * 0.5), int(gridSize * 0.5))
            diamondGroup.add(virtualDiamond)
            displayDrawing("X" + str(number) + " " + "分数:" + str(score), Chinese, red, gridSize - 10, 10)


            if pygame.key.get_pressed()[pygame.K_ESCAPE]:
                display = False
                pygame.quit()
                sys.exit()

    #循环遍历事件，根据事件类型进行相应响应
    for event in pygame.event.get():

        #若退出，则变量display变成false后窗口退出关闭
        if event.type==pygame.QUIT:
            display = False
            pygame.quit()
            sys.exit()

    #循环显示窗口
    pygame.display.update()